# 🚀 TECH MARKETPLACE

Marketplace moderne de gadgets tech avec dashboard admin avancé et analytics complètes.

## 📋 Fonctionnalités

### 🛒 Côté Client
- **Catalogue produits** avec filtres avancés et recherche
- **Variantes de produits** (couleur, taille, capacité)
- **Panier** avec gestion session/utilisateur
- **Système d'avis** clients avec notes
- **Commandes** avec suivi détaillé
- **Galerie multi-images** par produit
- **Design responsive** et animations fluides

### 👨‍💼 Dashboard Admin
- **Statistiques globales**
  - Nombre de visiteurs uniques
  - Nombre de commandes
  - Chiffre d'affaires (filtrable par période/catégorie)
  - Clients ayant commandé
  
- **Analytics Produits**
  - Produits les plus vus
  - Produits les plus commandés
  - Produits avec meilleur taux de conversion
  - Taux de conversion : (Ajouts panier + Commandes) / Vues × 100
  
- **Gestion**
  - Produits (CRUD + variantes)
  - Commandes (8 statuts détaillés)
  - Utilisateurs (3 rôles : client, admin, super_admin)
  - Avis clients (modération)
  - Alertes stock bas

### 🎨 Design
- **Style** : Dynamique/Tech avec couleurs vibrantes
- **Palette** : Cyan électrique (#00F0FF), Magenta (#FF006E), Violet néon (#8338EC)
- **Typo** : Orbitron (titres) + Rajdhani (corps)
- **Animations** : Transitions fluides, effets glow, micro-interactions

## 🏗️ Architecture

```
tech-marketplace/
├── backend/
│   ├── server.js              # Serveur Express
│   ├── database.js            # Configuration SQLite
│   ├── config/
│   │   └── config.js
│   ├── models/
│   │   ├── User.js
│   │   ├── Product.js
│   │   ├── Order.js
│   │   ├── Review.js
│   │   ├── Analytics.js
│   │   └── Category.js
│   ├── routes/
│   │   ├── auth.js
│   │   ├── products.js
│   │   ├── orders.js
│   │   ├── users.js
│   │   ├── reviews.js
│   │   ├── analytics.js
│   │   └── cart.js
│   └── middleware/
│       ├── auth.js
│       ├── roles.js
│       └── validator.js
├── frontend/
│   ├── index.html
│   ├── css/
│   │   ├── main.css
│   │   └── components.css
│   └── js/
│       ├── api.js
│       └── admin/
└── database/
    └── marketplace.db
```

## 🗄️ Base de Données

**Tables principales :**
- `users` - Utilisateurs (3 rôles)
- `products` - Produits
- `product_variants` - Variantes
- `orders` - Commandes
- `order_items` - Items de commandes
- `reviews` - Avis clients
- `analytics_events` - Événements trackés
- `cart_items` - Panier
- `visitor_sessions` - Sessions visiteurs
- `categories` - Catégories

**Statuts de commande :**
1. pending_payment
2. payment_confirmed
3. preparing
4. shipped
5. in_transit
6. delivered
7. cancelled
8. refunded

## 🚀 Installation

### 1. Installer les dépendances
```bash
npm install --break-system-packages
```

### 2. Configuration
Modifier `.env` si nécessaire :
```env
PORT=3000
JWT_SECRET=votre_secret
ADMIN_EMAIL=admin@techmarket.com
ADMIN_PASSWORD=Admin123!
SUPER_ADMIN_EMAIL=superadmin@techmarket.com
SUPER_ADMIN_PASSWORD=SuperAdmin123!
GA_TRACKING_ID=G-XXXXXXXXXX
```

### 3. Initialiser la base de données
```bash
npm run init-db
```

### 4. Démarrer le serveur
```bash
npm start
```

Le serveur démarre sur http://localhost:3000

## 🔑 Comptes Par Défaut

**Admin :**
- Email : admin@techmarket.com
- Mot de passe : Admin123!

**Super Admin :**
- Email : superadmin@techmarket.com
- Mot de passe : SuperAdmin123!

## 📡 API Endpoints

### Auth
- `POST /api/auth/register` - Inscription
- `POST /api/auth/login` - Connexion
- `GET /api/auth/me` - Utilisateur connecté
- `POST /api/auth/refresh` - Rafraîchir token

### Products
- `GET /api/products` - Liste produits
- `GET /api/products/:id` - Détails produit
- `POST /api/products` - Créer (admin)
- `PUT /api/products/:id` - Mettre à jour (admin)
- `DELETE /api/products/:id` - Supprimer (admin)
- `GET /api/products/:id/variants` - Variantes
- `POST /api/products/:id/variants` - Créer variante (admin)

### Cart
- `GET /api/cart` - Panier
- `POST /api/cart/add` - Ajouter au panier
- `PUT /api/cart/:itemId` - Mettre à jour quantité
- `DELETE /api/cart/:itemId` - Retirer du panier
- `DELETE /api/cart` - Vider panier

### Orders
- `GET /api/orders` - Liste commandes
- `GET /api/orders/:id` - Détails commande
- `POST /api/orders` - Créer commande
- `PUT /api/orders/:id/status` - Changer statut (admin)
- `POST /api/orders/:id/cancel` - Annuler

### Reviews
- `GET /api/reviews` - Liste avis
- `POST /api/reviews` - Créer avis
- `POST /api/reviews/:id/approve` - Approuver (admin)
- `POST /api/reviews/:id/reject` - Rejeter (admin)
- `GET /api/reviews/admin/pending` - Avis en attente (admin)

### Analytics (Admin)
- `GET /api/analytics/dashboard` - Dashboard global
- `GET /api/analytics/products/most-viewed` - Plus vus
- `GET /api/analytics/products/most-ordered` - Plus commandés
- `GET /api/analytics/products/top-conversion` - Meilleurs taux
- `GET /api/analytics/revenue/by-period` - CA par période
- `GET /api/analytics/revenue/by-category` - CA par catégorie
- `GET /api/analytics/traffic/by-period` - Trafic par période
- `GET /api/analytics/advanced` - Analytics complètes (super_admin)

## 📊 Analytics

### Métriques Calculées
- **Taux de conversion produit** = ((Ajouts panier + Commandes) / Vues) × 100
- **Chiffre d'affaires** = Filtrable par jour/semaine/mois + par catégorie
- **Visiteurs uniques** = Sessions distinctes trackées
- **Taux de conversion global** = (Clients commandes / Visiteurs) × 100

### Intégration Google Analytics
Remplacer `G-XXXXXXXXXX` dans :
- `.env` → `GA_TRACKING_ID`
- `frontend/index.html` → Script GA

## 🔒 Sécurité

- JWT tokens (access + refresh)
- Bcrypt pour mots de passe
- Validation input serveur
- Protection CSRF
- Rate limiting
- Rôles utilisateurs
- Foreign keys activées

## 🎨 Personnalisation

### Couleurs
Modifier `frontend/css/main.css` :
```css
:root {
  --primary: #00F0FF;
  --secondary: #FF006E;
  --accent: #8338EC;
  /* ... */
}
```

### Typographie
Changer les fonts Google :
```css
@import url('https://fonts.googleapis.com/css2?family=VotreFont...');
```

## 📱 Pages Disponibles

- `/` - Accueil
- `/products.html` - Catalogue
- `/product.html?id=X` - Détail produit
- `/cart.html` - Panier
- `/checkout.html` - Commande
- `/login.html` - Connexion
- `/register.html` - Inscription
- `/profile.html` - Profil utilisateur
- `/admin/dashboard.html` - Dashboard admin
- `/admin/products.html` - Gestion produits
- `/admin/orders.html` - Gestion commandes
- `/admin/users.html` - Gestion utilisateurs
- `/admin/analytics.html` - Analytics avancées

## 🛠️ Technologies

**Backend :**
- Node.js + Express
- SQLite (better-sqlite3)
- JWT (jsonwebtoken)
- Bcrypt
- Express-validator

**Frontend :**
- HTML5 / CSS3 / JavaScript vanilla
- Google Fonts (Orbitron + Rajdhani)
- Google Analytics

## 📝 TODO / Améliorations Futures

- [ ] Intégration paiement (Stripe/PayPal)
- [ ] Emails transactionnels
- [ ] Upload images produits
- [ ] Multi-langues
- [ ] Mode sombre/clair
- [ ] PWA
- [ ] Export données Excel/PDF
- [ ] Notifications push
- [ ] Chat support client

## 📄 Licence

MIT

## 👨‍💻 Support

Pour toute question ou problème, ouvrir une issue sur GitHub.

---

**Développé avec ⚡ par l'équipe Tech Marketplace**
