const API_URL = 'http://localhost:3000/api';

class API {
  constructor() {
    this.token = localStorage.getItem('token');
    this.sessionId = this.getOrCreateSessionId();
  }

  getOrCreateSessionId() {
    let sessionId = localStorage.getItem('sessionId');
    if (!sessionId) {
      sessionId = 'session_' + Date.now() + '_' + Math.random().toString(36).substring(7);
      localStorage.setItem('sessionId', sessionId);
    }
    return sessionId;
  }

  getHeaders(includeAuth = true) {
    const headers = {
      'Content-Type': 'application/json',
      'x-session-id': this.sessionId
    };
    if (includeAuth && this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }
    return headers;
  }

  async request(endpoint, options = {}) {
    const url = `${API_URL}${endpoint}`;
    const config = {
      ...options,
      headers: this.getHeaders(options.auth !== false)
    };

    try {
      const response = await fetch(url, config);
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Erreur réseau');
      }
      
      return data;
    } catch (error) {
      console.error('API Error:', error);
      throw error;
    }
  }

  async register(userData) {
    const data = await this.request('/auth/register', { method: 'POST', body: JSON.stringify(userData), auth: false });
    this.token = data.accessToken;
    localStorage.setItem('token', this.token);
    localStorage.setItem('user', JSON.stringify(data.user));
    return data;
  }

  async login(email, password) {
    const data = await this.request('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }), auth: false });
    this.token = data.accessToken;
    localStorage.setItem('token', this.token);
    localStorage.setItem('user', JSON.stringify(data.user));
    return data;
  }

  logout() {
    this.token = null;
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  }

  async getProducts(filters = {}) {
    const params = new URLSearchParams(filters);
    return this.request(`/products?${params}`, { auth: false });
  }

  async getProduct(id) {
    return this.request(`/products/${id}`, { auth: false });
  }

  async getCart() {
    return this.request('/cart', { auth: false });
  }

  async addToCart(productId, variantId, quantity) {
    return this.request('/cart/add', {
      method: 'POST',
      body: JSON.stringify({ product_id: productId, variant_id: variantId, quantity }),
      auth: false
    });
  }

  async trackEvent(eventType, productId, metadata) {
    return this.request('/analytics/track', {
      method: 'POST',
      body: JSON.stringify({ event_type: eventType, product_id: productId, metadata }),
      auth: false
    });
  }

  async getDashboard(filters = {}) {
    const params = new URLSearchParams(filters);
    return this.request(`/analytics/dashboard?${params}`);
  }

  async getOrders(filters = {}) {
    const params = new URLSearchParams(filters);
    return this.request(`/orders?${params}`);
  }

  async createProduct(productData) {
    return this.request('/products', { method: 'POST', body: JSON.stringify(productData) });
  }

  async updateProduct(id, productData) {
    return this.request(`/products/${id}`, { method: 'PUT', body: JSON.stringify(productData) });
  }

  async deleteProduct(id) {
    return this.request(`/products/${id}`, { method: 'DELETE' });
  }
}

const api = new API();
