const { db } = require('../database');

class Analytics {
  // Enregistrer un événement
  static trackEvent(eventData) {
    const {
      event_type, product_id, variant_id, user_id, session_id,
      metadata, ip_address, user_agent
    } = eventData;

    const stmt = db.prepare(`
      INSERT INTO analytics_events (
        event_type, product_id, variant_id, user_id, session_id,
        metadata, ip_address, user_agent
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run(
      event_type,
      product_id || null,
      variant_id || null,
      user_id || null,
      session_id,
      metadata ? JSON.stringify(metadata) : null,
      ip_address,
      user_agent
    );
  }

  // Gérer les sessions visiteurs
  static trackSession(sessionData) {
    const { session_id, user_id, ip_address, user_agent } = sessionData;

    const existingStmt = db.prepare('SELECT id FROM visitor_sessions WHERE session_id = ?');
    const existing = existingStmt.get(session_id);

    if (existing) {
      // Mettre à jour la session existante
      const updateStmt = db.prepare(`
        UPDATE visitor_sessions 
        SET last_visit = CURRENT_TIMESTAMP, 
            page_views = page_views + 1,
            user_id = COALESCE(?, user_id)
        WHERE session_id = ?
      `);
      updateStmt.run(user_id || null, session_id);
    } else {
      // Créer une nouvelle session
      const insertStmt = db.prepare(`
        INSERT INTO visitor_sessions (session_id, user_id, ip_address, user_agent)
        VALUES (?, ?, ?, ?)
      `);
      insertStmt.run(session_id, user_id || null, ip_address, user_agent);
    }
  }

  // Statistiques globales
  static getGlobalStats(filters = {}) {
    const stats = {};

    const fromDate = filters.from_date || '1970-01-01';
    const toDate = filters.to_date || '9999-12-31';

    // Nombre total de visiteurs uniques
    stats.uniqueVisitors = db.prepare(`
      SELECT COUNT(DISTINCT session_id) as count
      FROM visitor_sessions
      WHERE first_visit >= ? AND first_visit <= ?
    `).get(fromDate, toDate).count;

    // Nombre total de pages vues
    stats.pageViews = db.prepare(`
      SELECT SUM(page_views) as count
      FROM visitor_sessions
      WHERE first_visit >= ? AND first_visit <= ?
    `).get(fromDate, toDate).count || 0;

    // Nombre de clients ayant commandé
    stats.customersWithOrders = db.prepare(`
      SELECT COUNT(DISTINCT user_id) as count
      FROM orders
      WHERE created_at >= ? AND created_at <= ?
    `).get(fromDate, toDate).count;

    // Nombre total de commandes
    stats.totalOrders = db.prepare(`
      SELECT COUNT(*) as count
      FROM orders
      WHERE created_at >= ? AND created_at <= ?
    `).get(fromDate, toDate).count;

    // Chiffre d'affaires total
    stats.totalRevenue = db.prepare(`
      SELECT SUM(total) as revenue
      FROM orders
      WHERE payment_status = 'paid'
        AND created_at >= ? AND created_at <= ?
    `).get(fromDate, toDate).revenue || 0;

    // Taux de conversion global
    stats.conversionRate = stats.uniqueVisitors > 0 
      ? ((stats.customersWithOrders / stats.uniqueVisitors) * 100).toFixed(2)
      : 0;

    return stats;
  }

  // Produits les plus vus
  static getMostViewedProducts(limit = 10, filters = {}) {
    const params = [limit];
    let query = `
      SELECT 
        ae.product_id,
        p.name as product_name,
        p.featured_image,
        p.base_price,
        COUNT(*) as view_count
      FROM analytics_events ae
      LEFT JOIN products p ON ae.product_id = p.id
      WHERE ae.event_type = 'view' AND ae.product_id IS NOT NULL
    `;

    if (filters.from_date) {
      query += ' AND ae.created_at >= ?';
      params.unshift(filters.from_date);
    }

    if (filters.to_date) {
      query += ' AND ae.created_at <= ?';
      params.unshift(filters.to_date);
    }

    query += ' GROUP BY ae.product_id ORDER BY view_count DESC LIMIT ?';

    const stmt = db.prepare(query);
    return stmt.all(...params);
  }

  // Produits avec meilleur taux de conversion
  static getTopConversionProducts(limit = 10, filters = {}) {
    const params = [];
    let dateFilter = '';

    if (filters.from_date) {
      dateFilter = ' AND ae.created_at >= ?';
      params.push(filters.from_date);
    }

    if (filters.to_date) {
      dateFilter += ' AND ae.created_at <= ?';
      params.push(filters.to_date);
    }

    const query = `
      SELECT 
        p.id as product_id,
        p.name as product_name,
        p.featured_image,
        p.base_price,
        COALESCE(views.count, 0) as view_count,
        COALESCE(cart_adds.count, 0) as add_to_cart_count,
        COALESCE(orders.count, 0) as order_count,
        CASE 
          WHEN COALESCE(views.count, 0) > 0 
          THEN ROUND((COALESCE(cart_adds.count, 0) + COALESCE(orders.count, 0)) * 100.0 / views.count, 2)
          ELSE 0 
        END as conversion_rate
      FROM products p
      LEFT JOIN (
        SELECT product_id, COUNT(*) as count 
        FROM analytics_events 
        WHERE event_type = 'view' AND product_id IS NOT NULL ${dateFilter}
        GROUP BY product_id
      ) views ON p.id = views.product_id
      LEFT JOIN (
        SELECT product_id, COUNT(*) as count 
        FROM analytics_events 
        WHERE event_type = 'add_to_cart' AND product_id IS NOT NULL ${dateFilter}
        GROUP BY product_id
      ) cart_adds ON p.id = cart_adds.product_id
      LEFT JOIN (
        SELECT product_id, COUNT(DISTINCT order_id) as count 
        FROM order_items oi
        LEFT JOIN orders o ON oi.order_id = o.id
        WHERE o.payment_status = 'paid' ${dateFilter.replace(/ae\./g, 'o.')}
        GROUP BY product_id
      ) orders ON p.id = orders.product_id
      WHERE COALESCE(views.count, 0) > 0
      ORDER BY conversion_rate DESC
      LIMIT ?
    `;

    params.push(limit);
    const stmt = db.prepare(query);
    return stmt.all(...params);
  }

  // Produits les plus commandés
  static getMostOrderedProducts(limit = 10, filters = {}) {
    const params = [];
    let query = `
      SELECT 
        oi.product_id,
        p.name as product_name,
        p.featured_image,
        p.base_price,
        COUNT(DISTINCT oi.order_id) as order_count,
        SUM(oi.quantity) as total_quantity,
        SUM(oi.total_price) as total_revenue
      FROM order_items oi
      LEFT JOIN products p ON oi.product_id = p.id
      LEFT JOIN orders o ON oi.order_id = o.id
      WHERE o.payment_status = 'paid'
    `;

    if (filters.from_date) {
      query += ' AND o.created_at >= ?';
      params.push(filters.from_date);
    }

    if (filters.to_date) {
      query += ' AND o.created_at <= ?';
      params.push(filters.to_date);
    }

    query += ' GROUP BY oi.product_id ORDER BY total_quantity DESC LIMIT ?';
    params.push(limit);

    const stmt = db.prepare(query);
    return stmt.all(...params);
  }

  // Chiffre d'affaires par catégorie
  static getRevenueByCategory(filters = {}) {
    const params = [];
    let query = `
      SELECT 
        c.id as category_id,
        c.name as category_name,
        COUNT(DISTINCT o.id) as order_count,
        SUM(oi.total_price) as total_revenue,
        SUM(oi.quantity) as total_items_sold
      FROM order_items oi
      LEFT JOIN products p ON oi.product_id = p.id
      LEFT JOIN categories c ON p.category_id = c.id
      LEFT JOIN orders o ON oi.order_id = o.id
      WHERE o.payment_status = 'paid' AND c.id IS NOT NULL
    `;

    if (filters.from_date) {
      query += ' AND o.created_at >= ?';
      params.push(filters.from_date);
    }

    if (filters.to_date) {
      query += ' AND o.created_at <= ?';
      params.push(filters.to_date);
    }

    query += ' GROUP BY c.id ORDER BY total_revenue DESC';

    const stmt = db.prepare(query);
    return stmt.all(...params);
  }

  // Évolution du trafic par période
  static getTrafficByPeriod(period = 'day', filters = {}) {
    let dateFormat;
    switch (period) {
      case 'hour':
        dateFormat = '%Y-%m-%d %H:00:00';
        break;
      case 'day':
        dateFormat = '%Y-%m-%d';
        break;
      case 'week':
        dateFormat = '%Y-W%W';
        break;
      case 'month':
        dateFormat = '%Y-%m';
        break;
      default:
        dateFormat = '%Y-%m-%d';
    }

    const params = [];
    let query = `
      SELECT 
        strftime('${dateFormat}', first_visit) as period,
        COUNT(DISTINCT session_id) as unique_visitors,
        SUM(page_views) as total_page_views
      FROM visitor_sessions
      WHERE 1=1
    `;

    if (filters.from_date) {
      query += ' AND first_visit >= ?';
      params.push(filters.from_date);
    }

    if (filters.to_date) {
      query += ' AND first_visit <= ?';
      params.push(filters.to_date);
    }

    query += ' GROUP BY period ORDER BY period DESC';

    if (filters.limit) {
      query += ' LIMIT ?';
      params.push(filters.limit);
    }

    const stmt = db.prepare(query);
    return stmt.all(...params);
  }

  // Top recherches
  static getTopSearches(limit = 10, filters = {}) {
    const params = [];
    let query = `
      SELECT 
        json_extract(metadata, '$.query') as search_query,
        COUNT(*) as search_count
      FROM analytics_events
      WHERE event_type = 'search' AND metadata IS NOT NULL
    `;

    if (filters.from_date) {
      query += ' AND created_at >= ?';
      params.push(filters.from_date);
    }

    if (filters.to_date) {
      query += ' AND created_at <= ?';
      params.push(filters.to_date);
    }

    query += ' GROUP BY search_query ORDER BY search_count DESC LIMIT ?';
    params.push(limit);

    const stmt = db.prepare(query);
    return stmt.all(...params);
  }

  // Statistiques détaillées d'un produit
  static getProductAnalytics(productId, filters = {}) {
    const analytics = {};
    const params = [productId];

    let dateFilter = '';
    if (filters.from_date) {
      dateFilter = ' AND created_at >= ?';
      params.push(filters.from_date);
    }
    if (filters.to_date) {
      dateFilter += ' AND created_at <= ?';
      params.push(filters.to_date);
    }

    // Vues
    analytics.views = db.prepare(`
      SELECT COUNT(*) as count FROM analytics_events
      WHERE product_id = ? AND event_type = 'view' ${dateFilter}
    `).get(...params).count;

    // Ajouts au panier
    analytics.addToCart = db.prepare(`
      SELECT COUNT(*) as count FROM analytics_events
      WHERE product_id = ? AND event_type = 'add_to_cart' ${dateFilter}
    `).get(...params).count;

    // Achats
    const orderParams = [productId];
    let orderDateFilter = '';
    if (filters.from_date) {
      orderDateFilter = ' AND o.created_at >= ?';
      orderParams.push(filters.from_date);
    }
    if (filters.to_date) {
      orderDateFilter += ' AND o.created_at <= ?';
      orderParams.push(filters.to_date);
    }

    const orderStats = db.prepare(`
      SELECT 
        COUNT(DISTINCT oi.order_id) as order_count,
        SUM(oi.quantity) as total_quantity,
        SUM(oi.total_price) as total_revenue
      FROM order_items oi
      LEFT JOIN orders o ON oi.order_id = o.id
      WHERE oi.product_id = ? AND o.payment_status = 'paid' ${orderDateFilter}
    `).get(...orderParams);

    analytics.orders = orderStats.order_count || 0;
    analytics.totalQuantitySold = orderStats.total_quantity || 0;
    analytics.totalRevenue = orderStats.total_revenue || 0;

    // Taux de conversion
    analytics.conversionRate = analytics.views > 0 
      ? ((analytics.addToCart + analytics.orders) / analytics.views * 100).toFixed(2)
      : 0;

    return analytics;
  }
}

module.exports = Analytics;
