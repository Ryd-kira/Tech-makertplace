const { db } = require('../database');

class Review {
  // Créer un avis
  static create(reviewData) {
    const {
      product_id, user_id, order_id, rating, title, comment
    } = reviewData;

    // Vérifier si l'utilisateur a acheté le produit
    let verified_purchase = 0;
    if (order_id) {
      const stmt = db.prepare(`
        SELECT 1 FROM order_items oi
        LEFT JOIN orders o ON oi.order_id = o.id
        WHERE oi.product_id = ? 
          AND o.user_id = ? 
          AND oi.order_id = ?
          AND o.payment_status = 'paid'
      `);
      verified_purchase = stmt.get(product_id, user_id, order_id) ? 1 : 0;
    }

    const insertStmt = db.prepare(`
      INSERT INTO reviews (
        product_id, user_id, order_id, rating, title, comment, verified_purchase
      ) VALUES (?, ?, ?, ?, ?, ?, ?)
    `);

    const result = insertStmt.run(
      product_id, user_id, order_id || null, rating, title, comment, verified_purchase
    );

    return this.findById(result.lastInsertRowid);
  }

  // Trouver par ID
  static findById(id) {
    const stmt = db.prepare(`
      SELECT r.*, 
             u.first_name, u.last_name, u.email,
             p.name as product_name
      FROM reviews r
      LEFT JOIN users u ON r.user_id = u.id
      LEFT JOIN products p ON r.product_id = p.id
      WHERE r.id = ?
    `);

    return stmt.get(id);
  }

  // Lister les avis
  static getAll(filters = {}) {
    let query = `
      SELECT r.*, 
             u.first_name, u.last_name, u.email,
             p.name as product_name, p.featured_image
      FROM reviews r
      LEFT JOIN users u ON r.user_id = u.id
      LEFT JOIN products p ON r.product_id = p.id
      WHERE 1=1
    `;
    const params = [];

    if (filters.product_id) {
      query += ' AND r.product_id = ?';
      params.push(filters.product_id);
    }

    if (filters.user_id) {
      query += ' AND r.user_id = ?';
      params.push(filters.user_id);
    }

    if (filters.rating) {
      query += ' AND r.rating = ?';
      params.push(filters.rating);
    }

    if (filters.is_approved !== undefined) {
      query += ' AND r.is_approved = ?';
      params.push(filters.is_approved);
    }

    if (filters.verified_purchase !== undefined) {
      query += ' AND r.verified_purchase = ?';
      params.push(filters.verified_purchase);
    }

    // Tri
    const sortOptions = {
      'newest': 'r.created_at DESC',
      'oldest': 'r.created_at ASC',
      'highest': 'r.rating DESC',
      'lowest': 'r.rating ASC',
      'helpful': 'r.helpful_count DESC'
    };

    const sortBy = sortOptions[filters.sort] || 'r.created_at DESC';
    query += ` ORDER BY ${sortBy}`;

    if (filters.limit) {
      query += ' LIMIT ? OFFSET ?';
      params.push(filters.limit, filters.offset || 0);
    }

    const stmt = db.prepare(query);
    return stmt.all(...params);
  }

  // Compter les avis
  static count(filters = {}) {
    let query = 'SELECT COUNT(*) as total FROM reviews WHERE 1=1';
    const params = [];

    if (filters.product_id) {
      query += ' AND product_id = ?';
      params.push(filters.product_id);
    }

    if (filters.is_approved !== undefined) {
      query += ' AND is_approved = ?';
      params.push(filters.is_approved);
    }

    const stmt = db.prepare(query);
    return stmt.get(...params).total;
  }

  // Statistiques des avis d'un produit
  static getProductReviewStats(productId) {
    const stmt = db.prepare(`
      SELECT 
        COUNT(*) as total_reviews,
        AVG(rating) as average_rating,
        SUM(CASE WHEN rating = 5 THEN 1 ELSE 0 END) as five_star,
        SUM(CASE WHEN rating = 4 THEN 1 ELSE 0 END) as four_star,
        SUM(CASE WHEN rating = 3 THEN 1 ELSE 0 END) as three_star,
        SUM(CASE WHEN rating = 2 THEN 1 ELSE 0 END) as two_star,
        SUM(CASE WHEN rating = 1 THEN 1 ELSE 0 END) as one_star,
        SUM(verified_purchase) as verified_purchases
      FROM reviews
      WHERE product_id = ? AND is_approved = 1
    `);

    const stats = stmt.get(productId);

    if (stats && stats.total_reviews > 0) {
      stats.average_rating = parseFloat(stats.average_rating).toFixed(1);
      
      // Calculer les pourcentages
      stats.rating_distribution = {
        5: ((stats.five_star / stats.total_reviews) * 100).toFixed(1),
        4: ((stats.four_star / stats.total_reviews) * 100).toFixed(1),
        3: ((stats.three_star / stats.total_reviews) * 100).toFixed(1),
        2: ((stats.two_star / stats.total_reviews) * 100).toFixed(1),
        1: ((stats.one_star / stats.total_reviews) * 100).toFixed(1)
      };
    }

    return stats;
  }

  // Mettre à jour un avis
  static update(id, reviewData) {
    const fields = [];
    const values = [];

    ['rating', 'title', 'comment', 'is_approved'].forEach(field => {
      if (reviewData[field] !== undefined) {
        fields.push(`${field} = ?`);
        values.push(reviewData[field]);
      }
    });

    if (fields.length === 0) {
      return this.findById(id);
    }

    fields.push('updated_at = CURRENT_TIMESTAMP');
    values.push(id);

    const query = `UPDATE reviews SET ${fields.join(', ')} WHERE id = ?`;
    const stmt = db.prepare(query);
    stmt.run(...values);

    return this.findById(id);
  }

  // Approuver un avis
  static approve(id) {
    const stmt = db.prepare('UPDATE reviews SET is_approved = 1, updated_at = CURRENT_TIMESTAMP WHERE id = ?');
    stmt.run(id);
    return this.findById(id);
  }

  // Rejeter un avis
  static reject(id) {
    const stmt = db.prepare('UPDATE reviews SET is_approved = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?');
    stmt.run(id);
    return this.findById(id);
  }

  // Incrémenter le compteur "utile"
  static markHelpful(id) {
    const stmt = db.prepare('UPDATE reviews SET helpful_count = helpful_count + 1 WHERE id = ?');
    stmt.run(id);
    return this.findById(id);
  }

  // Supprimer un avis
  static delete(id) {
    const stmt = db.prepare('DELETE FROM reviews WHERE id = ?');
    stmt.run(id);
  }

  // Vérifier si un utilisateur peut laisser un avis
  static canUserReview(userId, productId) {
    // Vérifier si l'utilisateur a acheté le produit
    const purchaseStmt = db.prepare(`
      SELECT 1 FROM order_items oi
      LEFT JOIN orders o ON oi.order_id = o.id
      WHERE oi.product_id = ? 
        AND o.user_id = ?
        AND o.payment_status = 'paid'
      LIMIT 1
    `);
    
    const hasPurchased = purchaseStmt.get(productId, userId) !== undefined;

    // Vérifier si l'utilisateur a déjà laissé un avis
    const reviewStmt = db.prepare(`
      SELECT 1 FROM reviews
      WHERE product_id = ? AND user_id = ?
      LIMIT 1
    `);
    
    const hasReviewed = reviewStmt.get(productId, userId) !== undefined;

    return {
      canReview: hasPurchased && !hasReviewed,
      hasPurchased,
      hasReviewed
    };
  }

  // Avis en attente de modération
  static getPendingReviews(limit = 50) {
    const stmt = db.prepare(`
      SELECT r.*, 
             u.first_name, u.last_name, u.email,
             p.name as product_name, p.featured_image
      FROM reviews r
      LEFT JOIN users u ON r.user_id = u.id
      LEFT JOIN products p ON r.product_id = p.id
      WHERE r.is_approved = 0
      ORDER BY r.created_at ASC
      LIMIT ?
    `);

    return stmt.all(limit);
  }

  // Statistiques globales des avis
  static getGlobalStats() {
    const stats = {};

    // Total des avis
    stats.total = db.prepare('SELECT COUNT(*) as count FROM reviews').get().count;

    // Avis approuvés
    stats.approved = db.prepare('SELECT COUNT(*) as count FROM reviews WHERE is_approved = 1').get().count;

    // Avis en attente
    stats.pending = db.prepare('SELECT COUNT(*) as count FROM reviews WHERE is_approved = 0').get().count;

    // Note moyenne globale
    stats.averageRating = db.prepare(`
      SELECT AVG(rating) as avg FROM reviews WHERE is_approved = 1
    `).get().avg || 0;

    stats.averageRating = parseFloat(stats.averageRating).toFixed(1);

    // Achats vérifiés
    stats.verifiedPurchases = db.prepare(`
      SELECT COUNT(*) as count FROM reviews WHERE verified_purchase = 1
    `).get().count;

    return stats;
  }
}

module.exports = Review;
