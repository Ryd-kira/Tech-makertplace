const { db } = require('../database');

class Category {
  static getAll() {
    const stmt = db.prepare('SELECT * FROM categories WHERE is_active = 1 ORDER BY display_order, name');
    return stmt.all();
  }

  static findById(id) {
    const stmt = db.prepare('SELECT * FROM categories WHERE id = ?');
    return stmt.get(id);
  }

  static create(data) {
    const { name, slug, description, image_url, parent_id, display_order } = data;
    const stmt = db.prepare(`
      INSERT INTO categories (name, slug, description, image_url, parent_id, display_order)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    const result = stmt.run(name, slug, description, image_url || null, parent_id || null, display_order || 0);
    return this.findById(result.lastInsertRowid);
  }

  static update(id, data) {
    const fields = [];
    const values = [];
    ['name', 'slug', 'description', 'image_url', 'parent_id', 'display_order', 'is_active'].forEach(field => {
      if (data[field] !== undefined) {
        fields.push(`${field} = ?`);
        values.push(data[field]);
      }
    });
    if (fields.length === 0) return this.findById(id);
    values.push(id);
    const stmt = db.prepare(`UPDATE categories SET ${fields.join(', ')} WHERE id = ?`);
    stmt.run(...values);
    return this.findById(id);
  }

  static delete(id) {
    const stmt = db.prepare('DELETE FROM categories WHERE id = ?');
    stmt.run(id);
  }
}

module.exports = Category;
