const { db } = require('../database');

class Product {
  // Créer un produit
  static create(productData) {
    const {
      name, slug, description, short_description, category_id, base_price,
      stock_total, stock_alert_threshold, images, featured_image,
      specifications, is_featured, weight, dimensions
    } = productData;

    const stmt = db.prepare(`
      INSERT INTO products (
        name, slug, description, short_description, category_id, base_price,
        stock_total, stock_alert_threshold, images, featured_image,
        specifications, is_featured, weight, dimensions
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const result = stmt.run(
      name, slug, description, short_description, category_id, base_price,
      stock_total || 0, stock_alert_threshold || 10,
      images ? JSON.stringify(images) : null,
      featured_image,
      specifications ? JSON.stringify(specifications) : null,
      is_featured || 0, weight, dimensions ? JSON.stringify(dimensions) : null
    );

    return this.findById(result.lastInsertRowid);
  }

  // Trouver par ID
  static findById(id) {
    const stmt = db.prepare(`
      SELECT p.*, c.name as category_name, c.slug as category_slug
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE p.id = ?
    `);
    
    const product = stmt.get(id);
    
    if (product) {
      product.images = product.images ? JSON.parse(product.images) : [];
      product.specifications = product.specifications ? JSON.parse(product.specifications) : {};
      product.dimensions = product.dimensions ? JSON.parse(product.dimensions) : null;
      
      // Récupérer les variantes
      product.variants = this.getVariants(id);
      
      // Récupérer les stats
      product.stats = this.getProductStats(id);
    }
    
    return product;
  }

  // Trouver par slug
  static findBySlug(slug) {
    const stmt = db.prepare('SELECT id FROM products WHERE slug = ?');
    const result = stmt.get(slug);
    return result ? this.findById(result.id) : null;
  }

  // Lister les produits avec filtres
  static getAll(filters = {}) {
    let query = `
      SELECT p.*, c.name as category_name, c.slug as category_slug
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE 1=1
    `;
    const params = [];

    if (filters.category_id) {
      query += ' AND p.category_id = ?';
      params.push(filters.category_id);
    }

    if (filters.is_active !== undefined) {
      query += ' AND p.is_active = ?';
      params.push(filters.is_active);
    }

    if (filters.is_featured !== undefined) {
      query += ' AND p.is_featured = ?';
      params.push(filters.is_featured);
    }

    if (filters.search) {
      query += ' AND (p.name LIKE ? OR p.description LIKE ? OR p.short_description LIKE ?)';
      const searchTerm = `%${filters.search}%`;
      params.push(searchTerm, searchTerm, searchTerm);
    }

    if (filters.min_price) {
      query += ' AND p.base_price >= ?';
      params.push(filters.min_price);
    }

    if (filters.max_price) {
      query += ' AND p.base_price <= ?';
      params.push(filters.max_price);
    }

    if (filters.in_stock) {
      query += ' AND p.stock_total > 0';
    }

    // Tri
    const sortOptions = {
      'price_asc': 'p.base_price ASC',
      'price_desc': 'p.base_price DESC',
      'name_asc': 'p.name ASC',
      'name_desc': 'p.name DESC',
      'newest': 'p.created_at DESC',
      'oldest': 'p.created_at ASC',
      'popular': 'p.id DESC' // Sera amélioré avec les analytics
    };

    const sortBy = sortOptions[filters.sort] || 'p.created_at DESC';
    query += ` ORDER BY ${sortBy}`;

    if (filters.limit) {
      query += ' LIMIT ? OFFSET ?';
      params.push(filters.limit, filters.offset || 0);
    }

    const stmt = db.prepare(query);
    const products = stmt.all(...params);

    // Parser les JSON
    return products.map(p => ({
      ...p,
      images: p.images ? JSON.parse(p.images) : [],
      specifications: p.specifications ? JSON.parse(p.specifications) : {},
      dimensions: p.dimensions ? JSON.parse(p.dimensions) : null
    }));
  }

  // Compter les produits
  static count(filters = {}) {
    let query = 'SELECT COUNT(*) as total FROM products WHERE 1=1';
    const params = [];

    if (filters.category_id) {
      query += ' AND category_id = ?';
      params.push(filters.category_id);
    }

    if (filters.is_active !== undefined) {
      query += ' AND is_active = ?';
      params.push(filters.is_active);
    }

    if (filters.search) {
      query += ' AND (name LIKE ? OR description LIKE ?)';
      const searchTerm = `%${filters.search}%`;
      params.push(searchTerm, searchTerm);
    }

    const stmt = db.prepare(query);
    return stmt.get(...params).total;
  }

  // Mettre à jour un produit
  static update(id, productData) {
    const fields = [];
    const values = [];

    const allowedFields = [
      'name', 'slug', 'description', 'short_description', 'category_id',
      'base_price', 'stock_total', 'stock_alert_threshold', 'featured_image',
      'is_featured', 'is_active', 'weight'
    ];

    allowedFields.forEach(field => {
      if (productData[field] !== undefined) {
        fields.push(`${field} = ?`);
        values.push(productData[field]);
      }
    });

    // Champs JSON
    if (productData.images) {
      fields.push('images = ?');
      values.push(JSON.stringify(productData.images));
    }

    if (productData.specifications) {
      fields.push('specifications = ?');
      values.push(JSON.stringify(productData.specifications));
    }

    if (productData.dimensions) {
      fields.push('dimensions = ?');
      values.push(JSON.stringify(productData.dimensions));
    }

    if (fields.length === 0) {
      return this.findById(id);
    }

    fields.push('updated_at = CURRENT_TIMESTAMP');
    values.push(id);

    const query = `UPDATE products SET ${fields.join(', ')} WHERE id = ?`;
    const stmt = db.prepare(query);
    stmt.run(...values);

    return this.findById(id);
  }

  // Supprimer un produit
  static delete(id) {
    const stmt = db.prepare('DELETE FROM products WHERE id = ?');
    stmt.run(id);
  }

  // Gérer les variantes
  static getVariants(productId) {
    const stmt = db.prepare(`
      SELECT * FROM product_variants 
      WHERE product_id = ? AND is_active = 1
      ORDER BY name
    `);
    
    const variants = stmt.all(productId);
    return variants.map(v => ({
      ...v,
      attributes: v.attributes ? JSON.parse(v.attributes) : {}
    }));
  }

  static createVariant(variantData) {
    const { product_id, name, sku, attributes, price_adjustment, stock, image_url } = variantData;

    const stmt = db.prepare(`
      INSERT INTO product_variants (product_id, name, sku, attributes, price_adjustment, stock, image_url)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);

    const result = stmt.run(
      product_id, name, sku,
      JSON.stringify(attributes),
      price_adjustment || 0,
      stock || 0,
      image_url
    );

    return result.lastInsertRowid;
  }

  static updateVariant(variantId, variantData) {
    const fields = [];
    const values = [];

    ['name', 'sku', 'price_adjustment', 'stock', 'image_url', 'is_active'].forEach(field => {
      if (variantData[field] !== undefined) {
        fields.push(`${field} = ?`);
        values.push(variantData[field]);
      }
    });

    if (variantData.attributes) {
      fields.push('attributes = ?');
      values.push(JSON.stringify(variantData.attributes));
    }

    if (fields.length === 0) return;

    values.push(variantId);
    const query = `UPDATE product_variants SET ${fields.join(', ')} WHERE id = ?`;
    
    const stmt = db.prepare(query);
    stmt.run(...values);
  }

  static deleteVariant(variantId) {
    const stmt = db.prepare('DELETE FROM product_variants WHERE id = ?');
    stmt.run(variantId);
  }

  // Statistiques produit
  static getProductStats(productId) {
    const stats = {};

    // Nombre de vues
    stats.views = db.prepare(`
      SELECT COUNT(*) as count
      FROM analytics_events
      WHERE product_id = ? AND event_type = 'view'
    `).get(productId).count;

    // Nombre d'ajouts au panier
    stats.addToCart = db.prepare(`
      SELECT COUNT(*) as count
      FROM analytics_events
      WHERE product_id = ? AND event_type = 'add_to_cart'
    `).get(productId).count;

    // Nombre de commandes
    stats.orders = db.prepare(`
      SELECT COUNT(*) as count
      FROM order_items
      WHERE product_id = ?
    `).get(productId).count;

    // Note moyenne
    const reviewStats = db.prepare(`
      SELECT AVG(rating) as avg_rating, COUNT(*) as review_count
      FROM reviews
      WHERE product_id = ? AND is_approved = 1
    `).get(productId);

    stats.averageRating = reviewStats.avg_rating || 0;
    stats.reviewCount = reviewStats.review_count;

    // Taux de conversion
    stats.conversionRate = stats.views > 0 
      ? ((stats.addToCart + stats.orders) / stats.views * 100).toFixed(2)
      : 0;

    return stats;
  }

  // Produits en alerte stock
  static getLowStockProducts() {
    const stmt = db.prepare(`
      SELECT id, name, stock_total, stock_alert_threshold
      FROM products
      WHERE stock_total <= stock_alert_threshold AND is_active = 1
      ORDER BY stock_total ASC
    `);
    
    return stmt.all();
  }
}

module.exports = Product;
