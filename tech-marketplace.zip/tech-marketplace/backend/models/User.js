const { db } = require('../database');
const bcrypt = require('bcryptjs');

class User {
  // Créer un utilisateur
  static create(userData) {
    const { email, password, role = 'client', first_name, last_name, phone, address, city, postal_code, country } = userData;
    
    const password_hash = bcrypt.hashSync(password, 10);
    
    const stmt = db.prepare(`
      INSERT INTO users (email, password_hash, role, first_name, last_name, phone, address, city, postal_code, country)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    const result = stmt.run(email, password_hash, role, first_name, last_name, phone, address, city, postal_code, country);
    
    return this.findById(result.lastInsertRowid);
  }

  // Trouver par ID
  static findById(id) {
    const stmt = db.prepare('SELECT * FROM users WHERE id = ?');
    const user = stmt.get(id);
    
    if (user) {
      delete user.password_hash;
    }
    
    return user;
  }

  // Trouver par email
  static findByEmail(email) {
    const stmt = db.prepare('SELECT * FROM users WHERE email = ?');
    return stmt.get(email);
  }

  // Vérifier le mot de passe
  static verifyPassword(plainPassword, hashedPassword) {
    return bcrypt.compareSync(plainPassword, hashedPassword);
  }

  // Mettre à jour la dernière connexion
  static updateLastLogin(id) {
    const stmt = db.prepare('UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?');
    stmt.run(id);
  }

  // Lister tous les utilisateurs (admin)
  static getAll(filters = {}) {
    let query = 'SELECT id, email, role, first_name, last_name, phone, city, created_at, last_login, is_active FROM users WHERE 1=1';
    const params = [];

    if (filters.role) {
      query += ' AND role = ?';
      params.push(filters.role);
    }

    if (filters.is_active !== undefined) {
      query += ' AND is_active = ?';
      params.push(filters.is_active);
    }

    if (filters.search) {
      query += ' AND (email LIKE ? OR first_name LIKE ? OR last_name LIKE ?)';
      const searchTerm = `%${filters.search}%`;
      params.push(searchTerm, searchTerm, searchTerm);
    }

    query += ' ORDER BY created_at DESC';

    if (filters.limit) {
      query += ' LIMIT ? OFFSET ?';
      params.push(filters.limit, filters.offset || 0);
    }

    const stmt = db.prepare(query);
    return stmt.all(...params);
  }

  // Compter les utilisateurs
  static count(filters = {}) {
    let query = 'SELECT COUNT(*) as total FROM users WHERE 1=1';
    const params = [];

    if (filters.role) {
      query += ' AND role = ?';
      params.push(filters.role);
    }

    if (filters.is_active !== undefined) {
      query += ' AND is_active = ?';
      params.push(filters.is_active);
    }

    const stmt = db.prepare(query);
    return stmt.get(...params).total;
  }

  // Mettre à jour un utilisateur
  static update(id, userData) {
    const fields = [];
    const values = [];

    const allowedFields = ['first_name', 'last_name', 'phone', 'address', 'city', 'postal_code', 'country', 'is_active'];
    
    allowedFields.forEach(field => {
      if (userData[field] !== undefined) {
        fields.push(`${field} = ?`);
        values.push(userData[field]);
      }
    });

    if (fields.length === 0) {
      return this.findById(id);
    }

    values.push(id);
    const query = `UPDATE users SET ${fields.join(', ')}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`;
    
    const stmt = db.prepare(query);
    stmt.run(...values);
    
    return this.findById(id);
  }

  // Changer le mot de passe
  static changePassword(id, newPassword) {
    const password_hash = bcrypt.hashSync(newPassword, 10);
    const stmt = db.prepare('UPDATE users SET password_hash = ? WHERE id = ?');
    stmt.run(password_hash, id);
  }

  // Supprimer un utilisateur (soft delete)
  static delete(id) {
    const stmt = db.prepare('UPDATE users SET is_active = 0 WHERE id = ?');
    stmt.run(id);
  }

  // Statistiques utilisateurs
  static getStats() {
    const stats = {};

    // Total utilisateurs par rôle
    const roleStats = db.prepare(`
      SELECT role, COUNT(*) as count 
      FROM users 
      WHERE is_active = 1
      GROUP BY role
    `).all();
    
    stats.byRole = roleStats.reduce((acc, item) => {
      acc[item.role] = item.count;
      return acc;
    }, {});

    // Utilisateurs ayant commandé
    stats.withOrders = db.prepare(`
      SELECT COUNT(DISTINCT user_id) as count
      FROM orders
    `).get().count;

    // Nouveaux utilisateurs (30 derniers jours)
    stats.newLast30Days = db.prepare(`
      SELECT COUNT(*) as count
      FROM users
      WHERE created_at >= datetime('now', '-30 days')
    `).get().count;

    return stats;
  }
}

module.exports = User;
