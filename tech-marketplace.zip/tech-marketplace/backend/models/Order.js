const { db } = require('../database');

class Order {
  // Générer un numéro de commande unique
  static generateOrderNumber() {
    const timestamp = Date.now().toString(36).toUpperCase();
    const random = Math.random().toString(36).substring(2, 6).toUpperCase();
    return `ORD-${timestamp}-${random}`;
  }

  // Créer une commande
  static create(orderData, items) {
    const {
      user_id, subtotal, shipping_cost = 0, tax = 0, total,
      shipping_address, shipping_city, shipping_postal_code, shipping_country,
      shipping_phone, payment_method, notes
    } = orderData;

    const order_number = this.generateOrderNumber();

    // Transaction pour créer la commande et ses items
    const createOrder = db.transaction(() => {
      // Créer la commande
      const orderStmt = db.prepare(`
        INSERT INTO orders (
          order_number, user_id, status, subtotal, shipping_cost, tax, total,
          shipping_address, shipping_city, shipping_postal_code, shipping_country,
          shipping_phone, payment_method, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      const orderResult = orderStmt.run(
        order_number, user_id, 'pending_payment', subtotal, shipping_cost, tax, total,
        shipping_address, shipping_city, shipping_postal_code, shipping_country || 'Bénin',
        shipping_phone, payment_method, notes
      );

      const orderId = orderResult.lastInsertRowid;

      // Ajouter les items
      const itemStmt = db.prepare(`
        INSERT INTO order_items (
          order_id, product_id, variant_id, product_name, variant_name,
          quantity, unit_price, total_price
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `);

      const updateStockStmt = db.prepare(`
        UPDATE products SET stock_total = stock_total - ? WHERE id = ?
      `);

      const updateVariantStockStmt = db.prepare(`
        UPDATE product_variants SET stock = stock - ? WHERE id = ?
      `);

      items.forEach(item => {
        itemStmt.run(
          orderId,
          item.product_id,
          item.variant_id || null,
          item.product_name,
          item.variant_name || null,
          item.quantity,
          item.unit_price,
          item.total_price
        );

        // Mettre à jour le stock
        if (item.variant_id) {
          updateVariantStockStmt.run(item.quantity, item.variant_id);
        } else {
          updateStockStmt.run(item.quantity, item.product_id);
        }
      });

      return orderId;
    });

    const orderId = createOrder();
    return this.findById(orderId);
  }

  // Trouver par ID
  static findById(id) {
    const stmt = db.prepare(`
      SELECT o.*, u.email as user_email, u.first_name, u.last_name
      FROM orders o
      LEFT JOIN users u ON o.user_id = u.id
      WHERE o.id = ?
    `);

    const order = stmt.get(id);

    if (order) {
      // Récupérer les items
      order.items = this.getOrderItems(id);
    }

    return order;
  }

  // Trouver par numéro de commande
  static findByOrderNumber(orderNumber) {
    const stmt = db.prepare('SELECT id FROM orders WHERE order_number = ?');
    const result = stmt.get(orderNumber);
    return result ? this.findById(result.id) : null;
  }

  // Récupérer les items d'une commande
  static getOrderItems(orderId) {
    const stmt = db.prepare(`
      SELECT oi.*, p.featured_image, p.slug as product_slug
      FROM order_items oi
      LEFT JOIN products p ON oi.product_id = p.id
      WHERE oi.order_id = ?
    `);

    return stmt.all(orderId);
  }

  // Lister les commandes
  static getAll(filters = {}) {
    let query = `
      SELECT o.*, u.email as user_email, u.first_name, u.last_name,
             (SELECT COUNT(*) FROM order_items WHERE order_id = o.id) as item_count
      FROM orders o
      LEFT JOIN users u ON o.user_id = u.id
      WHERE 1=1
    `;
    const params = [];

    if (filters.user_id) {
      query += ' AND o.user_id = ?';
      params.push(filters.user_id);
    }

    if (filters.status) {
      query += ' AND o.status = ?';
      params.push(filters.status);
    }

    if (filters.payment_status) {
      query += ' AND o.payment_status = ?';
      params.push(filters.payment_status);
    }

    if (filters.from_date) {
      query += ' AND o.created_at >= ?';
      params.push(filters.from_date);
    }

    if (filters.to_date) {
      query += ' AND o.created_at <= ?';
      params.push(filters.to_date);
    }

    if (filters.search) {
      query += ' AND (o.order_number LIKE ? OR u.email LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ?)';
      const searchTerm = `%${filters.search}%`;
      params.push(searchTerm, searchTerm, searchTerm, searchTerm);
    }

    query += ' ORDER BY o.created_at DESC';

    if (filters.limit) {
      query += ' LIMIT ? OFFSET ?';
      params.push(filters.limit, filters.offset || 0);
    }

    const stmt = db.prepare(query);
    return stmt.all(...params);
  }

  // Compter les commandes
  static count(filters = {}) {
    let query = 'SELECT COUNT(*) as total FROM orders WHERE 1=1';
    const params = [];

    if (filters.user_id) {
      query += ' AND user_id = ?';
      params.push(filters.user_id);
    }

    if (filters.status) {
      query += ' AND status = ?';
      params.push(filters.status);
    }

    if (filters.from_date) {
      query += ' AND created_at >= ?';
      params.push(filters.from_date);
    }

    if (filters.to_date) {
      query += ' AND created_at <= ?';
      params.push(filters.to_date);
    }

    const stmt = db.prepare(query);
    return stmt.get(...params).total;
  }

  // Mettre à jour le statut
  static updateStatus(id, status, additionalData = {}) {
    const fields = ['status = ?'];
    const values = [status];

    // Mettre à jour les champs liés au statut
    if (status === 'shipped' && additionalData.tracking_number) {
      fields.push('tracking_number = ?', 'shipped_at = CURRENT_TIMESTAMP');
      values.push(additionalData.tracking_number);
    }

    if (status === 'delivered') {
      fields.push('delivered_at = CURRENT_TIMESTAMP');
    }

    if (status === 'payment_confirmed') {
      fields.push('payment_status = ?', 'payment_transaction_id = ?');
      values.push('paid', additionalData.transaction_id || null);
    }

    fields.push('updated_at = CURRENT_TIMESTAMP');
    values.push(id);

    const query = `UPDATE orders SET ${fields.join(', ')} WHERE id = ?`;
    const stmt = db.prepare(query);
    stmt.run(...values);

    return this.findById(id);
  }

  // Mettre à jour une commande
  static update(id, orderData) {
    const fields = [];
    const values = [];

    const allowedFields = [
      'shipping_address', 'shipping_city', 'shipping_postal_code',
      'shipping_country', 'shipping_phone', 'notes', 'tracking_number'
    ];

    allowedFields.forEach(field => {
      if (orderData[field] !== undefined) {
        fields.push(`${field} = ?`);
        values.push(orderData[field]);
      }
    });

    if (fields.length === 0) {
      return this.findById(id);
    }

    fields.push('updated_at = CURRENT_TIMESTAMP');
    values.push(id);

    const query = `UPDATE orders SET ${fields.join(', ')} WHERE id = ?`;
    const stmt = db.prepare(query);
    stmt.run(...values);

    return this.findById(id);
  }

  // Annuler une commande (avec remise en stock)
  static cancel(id) {
    const cancelOrder = db.transaction(() => {
      // Récupérer les items pour remettre en stock
      const items = this.getOrderItems(id);

      const updateStockStmt = db.prepare(`
        UPDATE products SET stock_total = stock_total + ? WHERE id = ?
      `);

      const updateVariantStockStmt = db.prepare(`
        UPDATE product_variants SET stock = stock + ? WHERE id = ?
      `);

      items.forEach(item => {
        if (item.variant_id) {
          updateVariantStockStmt.run(item.quantity, item.variant_id);
        } else {
          updateStockStmt.run(item.quantity, item.product_id);
        }
      });

      // Mettre à jour le statut
      const stmt = db.prepare('UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?');
      stmt.run('cancelled', id);
    });

    cancelOrder();
    return this.findById(id);
  }

  // Statistiques des commandes
  static getStats(filters = {}) {
    const stats = {};

    // Total des commandes
    stats.total = this.count(filters);

    // Répartition par statut
    let statusQuery = 'SELECT status, COUNT(*) as count FROM orders WHERE 1=1';
    const statusParams = [];

    if (filters.from_date) {
      statusQuery += ' AND created_at >= ?';
      statusParams.push(filters.from_date);
    }

    if (filters.to_date) {
      statusQuery += ' AND created_at <= ?';
      statusParams.push(filters.to_date);
    }

    statusQuery += ' GROUP BY status';

    const statusStmt = db.prepare(statusQuery);
    stats.byStatus = statusStmt.all(...statusParams).reduce((acc, item) => {
      acc[item.status] = item.count;
      return acc;
    }, {});

    // Chiffre d'affaires
    let revenueQuery = 'SELECT SUM(total) as revenue FROM orders WHERE payment_status = "paid"';
    const revenueParams = [];

    if (filters.from_date) {
      revenueQuery += ' AND created_at >= ?';
      revenueParams.push(filters.from_date);
    }

    if (filters.to_date) {
      revenueQuery += ' AND created_at <= ?';
      revenueParams.push(filters.to_date);
    }

    const revenueStmt = db.prepare(revenueQuery);
    stats.revenue = revenueStmt.get(...revenueParams).revenue || 0;

    // Panier moyen
    stats.averageOrderValue = stats.total > 0 ? (stats.revenue / stats.total).toFixed(2) : 0;

    return stats;
  }

  // Chiffre d'affaires par période
  static getRevenueByPeriod(period = 'day', filters = {}) {
    let dateFormat;
    switch (period) {
      case 'hour':
        dateFormat = '%Y-%m-%d %H:00:00';
        break;
      case 'day':
        dateFormat = '%Y-%m-%d';
        break;
      case 'week':
        dateFormat = '%Y-W%W';
        break;
      case 'month':
        dateFormat = '%Y-%m';
        break;
      case 'year':
        dateFormat = '%Y';
        break;
      default:
        dateFormat = '%Y-%m-%d';
    }

    let query = `
      SELECT 
        strftime('${dateFormat}', created_at) as period,
        COUNT(*) as order_count,
        SUM(total) as revenue,
        AVG(total) as avg_order_value
      FROM orders
      WHERE payment_status = 'paid'
    `;
    const params = [];

    if (filters.from_date) {
      query += ' AND created_at >= ?';
      params.push(filters.from_date);
    }

    if (filters.to_date) {
      query += ' AND created_at <= ?';
      params.push(filters.to_date);
    }

    query += ' GROUP BY period ORDER BY period DESC';

    if (filters.limit) {
      query += ' LIMIT ?';
      params.push(filters.limit);
    }

    const stmt = db.prepare(query);
    return stmt.all(...params);
  }

  // Top produits commandés
  static getTopProducts(limit = 10, filters = {}) {
    let query = `
      SELECT 
        oi.product_id,
        oi.product_name,
        p.featured_image,
        SUM(oi.quantity) as total_quantity,
        COUNT(DISTINCT oi.order_id) as order_count,
        SUM(oi.total_price) as total_revenue
      FROM order_items oi
      LEFT JOIN products p ON oi.product_id = p.id
      LEFT JOIN orders o ON oi.order_id = o.id
      WHERE o.payment_status = 'paid'
    `;
    const params = [];

    if (filters.from_date) {
      query += ' AND o.created_at >= ?';
      params.push(filters.from_date);
    }

    if (filters.to_date) {
      query += ' AND o.created_at <= ?';
      params.push(filters.to_date);
    }

    query += ' GROUP BY oi.product_id ORDER BY total_quantity DESC LIMIT ?';
    params.push(limit);

    const stmt = db.prepare(query);
    return stmt.all(...params);
  }
}

module.exports = Order;
