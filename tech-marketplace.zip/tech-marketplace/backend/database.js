const Database = require('better-sqlite3');
const path = require('path');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const dbPath = path.join(__dirname, '..', 'database', 'marketplace.db');
const db = new Database(dbPath);

// Activer les foreign keys
db.pragma('foreign_keys = ON');

function initDatabase() {
  console.log('🗄️  Initialisation de la base de données...');

  // Table des utilisateurs
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('client', 'admin', 'super_admin')) DEFAULT 'client',
      first_name TEXT,
      last_name TEXT,
      phone TEXT,
      address TEXT,
      city TEXT,
      postal_code TEXT,
      country TEXT DEFAULT 'Bénin',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      last_login DATETIME,
      is_active INTEGER DEFAULT 1
    )
  `);

  // Table des catégories
  db.exec(`
    CREATE TABLE IF NOT EXISTS categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      description TEXT,
      image_url TEXT,
      parent_id INTEGER,
      display_order INTEGER DEFAULT 0,
      is_active INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE SET NULL
    )
  `);

  // Table des produits
  db.exec(`
    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      description TEXT,
      short_description TEXT,
      category_id INTEGER,
      base_price REAL NOT NULL,
      stock_total INTEGER DEFAULT 0,
      stock_alert_threshold INTEGER DEFAULT 10,
      images TEXT, -- JSON array d'URLs
      featured_image TEXT,
      specifications TEXT, -- JSON des specs techniques
      is_featured INTEGER DEFAULT 0,
      is_active INTEGER DEFAULT 1,
      weight REAL, -- en kg
      dimensions TEXT, -- JSON {length, width, height}
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
    )
  `);

  // Table des variantes de produits
  db.exec(`
    CREATE TABLE IF NOT EXISTS product_variants (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      sku TEXT UNIQUE NOT NULL,
      attributes TEXT NOT NULL, -- JSON {color: "noir", capacity: "128GB"}
      price_adjustment REAL DEFAULT 0,
      stock INTEGER DEFAULT 0,
      image_url TEXT,
      is_active INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    )
  `);

  // Table des commandes
  db.exec(`
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_number TEXT UNIQUE NOT NULL,
      user_id INTEGER NOT NULL,
      status TEXT NOT NULL CHECK(status IN (
        'pending_payment',
        'payment_confirmed',
        'preparing',
        'shipped',
        'in_transit',
        'delivered',
        'cancelled',
        'refunded'
      )) DEFAULT 'pending_payment',
      subtotal REAL NOT NULL,
      shipping_cost REAL DEFAULT 0,
      tax REAL DEFAULT 0,
      total REAL NOT NULL,
      
      -- Adresse de livraison
      shipping_address TEXT NOT NULL,
      shipping_city TEXT NOT NULL,
      shipping_postal_code TEXT NOT NULL,
      shipping_country TEXT DEFAULT 'Bénin',
      shipping_phone TEXT,
      
      -- Informations de paiement
      payment_method TEXT,
      payment_status TEXT DEFAULT 'pending',
      payment_transaction_id TEXT,
      
      -- Tracking
      tracking_number TEXT,
      shipped_at DATETIME,
      delivered_at DATETIME,
      
      notes TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )
  `);

  // Table des items de commande
  db.exec(`
    CREATE TABLE IF NOT EXISTS order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      variant_id INTEGER,
      product_name TEXT NOT NULL,
      variant_name TEXT,
      quantity INTEGER NOT NULL,
      unit_price REAL NOT NULL,
      total_price REAL NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
      FOREIGN KEY (product_id) REFERENCES products(id),
      FOREIGN KEY (variant_id) REFERENCES product_variants(id)
    )
  `);

  // Table des avis clients
  db.exec(`
    CREATE TABLE IF NOT EXISTS reviews (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      order_id INTEGER,
      rating INTEGER NOT NULL CHECK(rating >= 1 AND rating <= 5),
      title TEXT,
      comment TEXT,
      verified_purchase INTEGER DEFAULT 0,
      is_approved INTEGER DEFAULT 0,
      helpful_count INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL,
      UNIQUE(product_id, user_id, order_id)
    )
  `);

  // Table des événements analytics
  db.exec(`
    CREATE TABLE IF NOT EXISTS analytics_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      event_type TEXT NOT NULL CHECK(event_type IN ('view', 'add_to_cart', 'remove_from_cart', 'purchase', 'search')),
      product_id INTEGER,
      variant_id INTEGER,
      user_id INTEGER,
      session_id TEXT NOT NULL,
      metadata TEXT, -- JSON pour données supplémentaires
      ip_address TEXT,
      user_agent TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL,
      FOREIGN KEY (variant_id) REFERENCES product_variants(id) ON DELETE SET NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    )
  `);

  // Table du panier
  db.exec(`
    CREATE TABLE IF NOT EXISTS cart_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      session_id TEXT,
      product_id INTEGER NOT NULL,
      variant_id INTEGER,
      quantity INTEGER NOT NULL DEFAULT 1,
      added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
      FOREIGN KEY (variant_id) REFERENCES product_variants(id) ON DELETE CASCADE
    )
  `);

  // Table des sessions visiteurs
  db.exec(`
    CREATE TABLE IF NOT EXISTS visitor_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id TEXT UNIQUE NOT NULL,
      user_id INTEGER,
      ip_address TEXT,
      user_agent TEXT,
      first_visit DATETIME DEFAULT CURRENT_TIMESTAMP,
      last_visit DATETIME DEFAULT CURRENT_TIMESTAMP,
      page_views INTEGER DEFAULT 1,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    )
  `);

  // Indices pour optimisation
  console.log('📊 Création des indices...');
  
  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
    CREATE INDEX IF NOT EXISTS idx_products_active ON products(is_active);
    CREATE INDEX IF NOT EXISTS idx_products_featured ON products(is_featured);
    CREATE INDEX IF NOT EXISTS idx_variants_product ON product_variants(product_id);
    CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id);
    CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
    CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);
    CREATE INDEX IF NOT EXISTS idx_order_items_product ON order_items(product_id);
    CREATE INDEX IF NOT EXISTS idx_reviews_product ON reviews(product_id);
    CREATE INDEX IF NOT EXISTS idx_reviews_user ON reviews(user_id);
    CREATE INDEX IF NOT EXISTS idx_analytics_product ON analytics_events(product_id);
    CREATE INDEX IF NOT EXISTS idx_analytics_session ON analytics_events(session_id);
    CREATE INDEX IF NOT EXISTS idx_analytics_type ON analytics_events(event_type);
    CREATE INDEX IF NOT EXISTS idx_cart_user ON cart_items(user_id);
    CREATE INDEX IF NOT EXISTS idx_cart_session ON cart_items(session_id);
  `);

  console.log('✅ Schéma de base de données créé avec succès!');
}

function seedInitialData() {
  console.log('🌱 Insertion des données initiales...');

  // Créer les utilisateurs admin par défaut
  const adminPassword = bcrypt.hashSync(process.env.ADMIN_PASSWORD || 'Admin123!', 10);
  const superAdminPassword = bcrypt.hashSync(process.env.SUPER_ADMIN_PASSWORD || 'SuperAdmin123!', 10);

  const insertUser = db.prepare(`
    INSERT OR IGNORE INTO users (email, password_hash, role, first_name, last_name)
    VALUES (?, ?, ?, ?, ?)
  `);

  insertUser.run(process.env.ADMIN_EMAIL || 'admin@techmarket.com', adminPassword, 'admin', 'Admin', 'User');
  insertUser.run(process.env.SUPER_ADMIN_EMAIL || 'superadmin@techmarket.com', superAdminPassword, 'super_admin', 'Super', 'Admin');

  // Créer des catégories par défaut
  const insertCategory = db.prepare(`
    INSERT OR IGNORE INTO categories (name, slug, description)
    VALUES (?, ?, ?)
  `);

  const categories = [
    ['Smartphones', 'smartphones', 'Téléphones intelligents et accessoires'],
    ['Ordinateurs', 'ordinateurs', 'Laptops, PC de bureau et composants'],
    ['Audio', 'audio', 'Casques, écouteurs et enceintes'],
    ['Montres Connectées', 'montres-connectees', 'Smartwatches et bracelets fitness'],
    ['Gaming', 'gaming', 'Consoles, manettes et accessoires'],
    ['Domotique', 'domotique', 'Maison intelligente et IoT'],
    ['Photo & Vidéo', 'photo-video', 'Caméras, drones et accessoires'],
    ['Accessoires', 'accessoires', 'Câbles, chargeurs et gadgets divers']
  ];

  categories.forEach(cat => insertCategory.run(...cat));

  console.log('✅ Données initiales insérées!');
  console.log('\n🔐 Comptes créés:');
  console.log(`   Admin: ${process.env.ADMIN_EMAIL || 'admin@techmarket.com'}`);
  console.log(`   Super Admin: ${process.env.SUPER_ADMIN_EMAIL || 'superadmin@techmarket.com'}`);
}

// Exporter la connexion DB et les fonctions
module.exports = {
  db,
  initDatabase,
  seedInitialData
};

// Si exécuté directement
if (require.main === module) {
  initDatabase();
  seedInitialData();
  console.log('\n✨ Base de données prête à l\'emploi!\n');
  db.close();
}
