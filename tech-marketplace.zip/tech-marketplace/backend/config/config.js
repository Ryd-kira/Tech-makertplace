require('dotenv').config();

module.exports = {
  port: process.env.PORT || 3000,
  nodeEnv: process.env.NODE_ENV || 'development',
  
  jwt: {
    secret: process.env.JWT_SECRET || 'your-secret-key-change-in-production',
    refreshSecret: process.env.JWT_REFRESH_SECRET || 'your-refresh-secret',
    expiresIn: process.env.JWT_EXPIRES_IN || '1h',
    refreshExpiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d'
  },
  
  db: {
    path: process.env.DB_PATH || './database/marketplace.db'
  },
  
  admin: {
    email: process.env.ADMIN_EMAIL || 'admin@techmarket.com',
    password: process.env.ADMIN_PASSWORD || 'Admin123!',
    superAdminEmail: process.env.SUPER_ADMIN_EMAIL || 'superadmin@techmarket.com',
    superAdminPassword: process.env.SUPER_ADMIN_PASSWORD || 'SuperAdmin123!'
  },
  
  analytics: {
    gaTrackingId: process.env.GA_TRACKING_ID || ''
  },
  
  stock: {
    alertThreshold: parseInt(process.env.STOCK_ALERT_THRESHOLD) || 10
  }
};
