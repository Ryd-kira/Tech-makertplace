const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const path = require('path');
const config = require('./config/config');
const { initDatabase, seedInitialData } = require('./database');

// Initialiser la base de données
try {
  initDatabase();
  seedInitialData();
  console.log('✅ Base de données initialisée\n');
} catch (error) {
  console.error('❌ Erreur initialisation base de données:', error);
}

const app = express();

// Middlewares globaux
app.use(cors({
  origin: ['http://localhost:3000', 'http://127.0.0.1:3000'],
  credentials: true
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(cookieParser());

// Servir les fichiers statiques du frontend
app.use(express.static(path.join(__dirname, '..', 'frontend')));

// Routes API
app.use('/api/auth', require('./routes/auth'));
app.use('/api/products', require('./routes/products'));
app.use('/api/orders', require('./routes/orders'));
app.use('/api/users', require('./routes/users'));
app.use('/api/reviews', require('./routes/reviews'));
app.use('/api/analytics', require('./routes/analytics'));
app.use('/api/cart', require('./routes/cart'));

// Route santé
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    timestamp: new Date().toISOString(),
    environment: config.nodeEnv
  });
});

// Toutes les autres routes renvoient index.html (SPA routing)
app.get('*', (req, res) => {
  if (!req.path.startsWith('/api')) {
    res.sendFile(path.join(__dirname, '..', 'frontend', 'index.html'));
  } else {
    res.status(404).json({ error: 'Route API non trouvée' });
  }
});

// Gestion des erreurs globale
app.use((err, req, res, next) => {
  console.error('Erreur serveur:', err);
  res.status(err.status || 500).json({
    error: err.message || 'Erreur interne du serveur',
    ...(config.nodeEnv === 'development' && { stack: err.stack })
  });
});

// Démarrer le serveur
const PORT = config.port;
app.listen(PORT, () => {
  console.log(`
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║        🚀 TECH MARKETPLACE SERVER DÉMARRÉ 🚀             ║
║                                                           ║
║  Serveur:      http://localhost:${PORT}                       ║
║  API:          http://localhost:${PORT}/api                   ║
║  Environment:  ${config.nodeEnv.toUpperCase().padEnd(37)}║
║                                                           ║
║  📊 Endpoints disponibles:                                ║
║  • GET  /api/health         - Status serveur              ║
║  • POST /api/auth/register  - Inscription                 ║
║  • POST /api/auth/login     - Connexion                   ║
║  • GET  /api/products       - Liste produits              ║
║  • GET  /api/orders         - Commandes                   ║
║  • GET  /api/analytics      - Analytics                   ║
║                                                           ║
║  🔐 Comptes admin par défaut:                             ║
║  Admin:       ${config.admin.email.padEnd(38)}║
║  Super Admin: ${config.admin.superAdminEmail.padEnd(38)}║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
  `);
});

module.exports = app;
