const express = require('express');
const router = express.Router();
const { body, param, query } = require('express-validator');
const Product = require('../models/Product');
const Analytics = require('../models/Analytics');
const { authenticateToken, optionalAuth } = require('../middleware/auth');
const { requireAdmin } = require('../middleware/roles');
const { handleValidationErrors, validatePagination } = require('../middleware/validator');

// Validation création/mise à jour produit
const productValidation = [
  body('name').trim().notEmpty().withMessage('Le nom du produit est requis'),
  body('slug').trim().notEmpty().withMessage('Le slug est requis'),
  body('base_price').isFloat({ min: 0 }).withMessage('Le prix doit être positif'),
  body('category_id').optional().isInt().withMessage('ID catégorie invalide'),
  body('stock_total').optional().isInt({ min: 0 }).withMessage('Le stock doit être >= 0')
];

// GET /api/products - Liste des produits (public)
router.get('/', optionalAuth, validatePagination, async (req, res) => {
  try {
    const {
      category_id, is_featured, search, min_price, max_price,
      in_stock, sort
    } = req.query;

    const { page, limit, offset } = req.pagination;

    const filters = {
      category_id,
      is_featured: is_featured === 'true' ? 1 : undefined,
      is_active: 1, // Seulement les produits actifs pour le public
      search,
      min_price: min_price ? parseFloat(min_price) : undefined,
      max_price: max_price ? parseFloat(max_price) : undefined,
      in_stock: in_stock === 'true' ? true : undefined,
      sort,
      limit,
      offset
    };

    const products = Product.getAll(filters);
    const total = Product.count(filters);

    res.json({
      products,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Erreur récupération produits:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// GET /api/products/:id - Détails d'un produit
router.get('/:id', optionalAuth, async (req, res) => {
  try {
    const product = Product.findById(req.params.id);

    if (!product) {
      return res.status(404).json({ error: 'Produit non trouvé' });
    }

    // Si produit inactif, seuls les admins peuvent le voir
    if (!product.is_active && (!req.user || (req.user.role !== 'admin' && req.user.role !== 'super_admin'))) {
      return res.status(404).json({ error: 'Produit non trouvé' });
    }

    // Tracker la vue du produit
    const sessionId = req.headers['x-session-id'] || 'anonymous';
    Analytics.trackEvent({
      event_type: 'view',
      product_id: product.id,
      user_id: req.user?.id,
      session_id: sessionId,
      ip_address: req.ip,
      user_agent: req.headers['user-agent']
    });

    res.json({ product });
  } catch (error) {
    console.error('Erreur récupération produit:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// GET /api/products/slug/:slug - Détails par slug
router.get('/slug/:slug', optionalAuth, async (req, res) => {
  try {
    const product = Product.findBySlug(req.params.slug);

    if (!product) {
      return res.status(404).json({ error: 'Produit non trouvé' });
    }

    if (!product.is_active && (!req.user || (req.user.role !== 'admin' && req.user.role !== 'super_admin'))) {
      return res.status(404).json({ error: 'Produit non trouvé' });
    }

    // Tracker la vue
    const sessionId = req.headers['x-session-id'] || 'anonymous';
    Analytics.trackEvent({
      event_type: 'view',
      product_id: product.id,
      user_id: req.user?.id,
      session_id: sessionId,
      ip_address: req.ip,
      user_agent: req.headers['user-agent']
    });

    res.json({ product });
  } catch (error) {
    console.error('Erreur récupération produit:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// POST /api/products - Créer un produit (admin only)
router.post('/',
  authenticateToken,
  requireAdmin,
  productValidation,
  handleValidationErrors,
  async (req, res) => {
    try {
      const product = Product.create(req.body);
      res.status(201).json({
        message: 'Produit créé avec succès',
        product
      });
    } catch (error) {
      console.error('Erreur création produit:', error);
      
      if (error.message && error.message.includes('UNIQUE constraint')) {
        return res.status(400).json({ error: 'Un produit avec ce slug existe déjà' });
      }
      
      res.status(500).json({ error: 'Erreur lors de la création du produit' });
    }
  }
);

// PUT /api/products/:id - Mettre à jour un produit (admin only)
router.put('/:id',
  authenticateToken,
  requireAdmin,
  productValidation,
  handleValidationErrors,
  async (req, res) => {
    try {
      const product = Product.findById(req.params.id);
      
      if (!product) {
        return res.status(404).json({ error: 'Produit non trouvé' });
      }

      const updatedProduct = Product.update(req.params.id, req.body);
      
      res.json({
        message: 'Produit mis à jour avec succès',
        product: updatedProduct
      });
    } catch (error) {
      console.error('Erreur mise à jour produit:', error);
      res.status(500).json({ error: 'Erreur lors de la mise à jour' });
    }
  }
);

// DELETE /api/products/:id - Supprimer un produit (admin only)
router.delete('/:id',
  authenticateToken,
  requireAdmin,
  async (req, res) => {
    try {
      const product = Product.findById(req.params.id);
      
      if (!product) {
        return res.status(404).json({ error: 'Produit non trouvé' });
      }

      Product.delete(req.params.id);
      
      res.json({ message: 'Produit supprimé avec succès' });
    } catch (error) {
      console.error('Erreur suppression produit:', error);
      res.status(500).json({ error: 'Erreur lors de la suppression' });
    }
  }
);

// GET /api/products/:id/variants - Récupérer les variantes
router.get('/:id/variants', async (req, res) => {
  try {
    const variants = Product.getVariants(req.params.id);
    res.json({ variants });
  } catch (error) {
    console.error('Erreur récupération variantes:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// POST /api/products/:id/variants - Créer une variante (admin only)
router.post('/:id/variants',
  authenticateToken,
  requireAdmin,
  [
    body('name').trim().notEmpty().withMessage('Le nom de la variante est requis'),
    body('sku').trim().notEmpty().withMessage('Le SKU est requis'),
    body('attributes').isObject().withMessage('Les attributs doivent être un objet')
  ],
  handleValidationErrors,
  async (req, res) => {
    try {
      const product = Product.findById(req.params.id);
      
      if (!product) {
        return res.status(404).json({ error: 'Produit non trouvé' });
      }

      const variantId = Product.createVariant({
        product_id: req.params.id,
        ...req.body
      });

      res.status(201).json({
        message: 'Variante créée avec succès',
        variantId
      });
    } catch (error) {
      console.error('Erreur création variante:', error);
      res.status(500).json({ error: 'Erreur lors de la création de la variante' });
    }
  }
);

// PUT /api/products/:productId/variants/:variantId - Mettre à jour une variante (admin only)
router.put('/:productId/variants/:variantId',
  authenticateToken,
  requireAdmin,
  async (req, res) => {
    try {
      Product.updateVariant(req.params.variantId, req.body);
      
      res.json({ message: 'Variante mise à jour avec succès' });
    } catch (error) {
      console.error('Erreur mise à jour variante:', error);
      res.status(500).json({ error: 'Erreur lors de la mise à jour' });
    }
  }
);

// DELETE /api/products/:productId/variants/:variantId - Supprimer une variante (admin only)
router.delete('/:productId/variants/:variantId',
  authenticateToken,
  requireAdmin,
  async (req, res) => {
    try {
      Product.deleteVariant(req.params.variantId);
      res.json({ message: 'Variante supprimée avec succès' });
    } catch (error) {
      console.error('Erreur suppression variante:', error);
      res.status(500).json({ error: 'Erreur lors de la suppression' });
    }
  }
);

// GET /api/products/admin/low-stock - Produits en alerte stock (admin only)
router.get('/admin/low-stock',
  authenticateToken,
  requireAdmin,
  async (req, res) => {
    try {
      const products = Product.getLowStockProducts();
      res.json({ products });
    } catch (error) {
      console.error('Erreur récupération produits low stock:', error);
      res.status(500).json({ error: 'Erreur serveur' });
    }
  }
);

module.exports = router;
