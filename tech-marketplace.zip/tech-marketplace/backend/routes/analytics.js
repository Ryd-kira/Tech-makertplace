const express = require('express');
const router = express.Router();
const Analytics = require('../models/Analytics');
const Order = require('../models/Order');
const User = require('../models/User');
const Review = require('../models/Review');
const { authenticateToken } = require('../middleware/auth');
const { requireAdmin, requireSuperAdmin } = require('../middleware/roles');

// POST /api/analytics/track - Enregistrer un événement
router.post('/track', async (req, res) => {
  try {
    const { event_type, product_id, variant_id, metadata } = req.body;
    const sessionId = req.headers['x-session-id'] || 'anonymous';

    Analytics.trackEvent({
      event_type,
      product_id,
      variant_id,
      user_id: req.user?.id,
      session_id: sessionId,
      metadata,
      ip_address: req.ip,
      user_agent: req.headers['user-agent']
    });

    res.json({ message: 'Événement enregistré' });
  } catch (error) {
    console.error('Erreur tracking:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// POST /api/analytics/session - Enregistrer une session visiteur
router.post('/session', async (req, res) => {
  try {
    const sessionId = req.headers['x-session-id'] || 'anonymous';

    Analytics.trackSession({
      session_id: sessionId,
      user_id: req.user?.id,
      ip_address: req.ip,
      user_agent: req.headers['user-agent']
    });

    res.json({ message: 'Session enregistrée' });
  } catch (error) {
    console.error('Erreur tracking session:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// GET /api/analytics/dashboard - Statistiques globales du dashboard (admin only)
router.get('/dashboard', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { from_date, to_date } = req.query;
    const filters = { from_date, to_date };

    const dashboard = {
      global: Analytics.getGlobalStats(filters),
      orders: Order.getStats(filters),
      users: User.getStats(),
      reviews: Review.getGlobalStats()
    };

    res.json({ dashboard });
  } catch (error) {
    console.error('Erreur dashboard:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// GET /api/analytics/products/most-viewed - Produits les plus vus
router.get('/products/most-viewed', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { limit = 10, from_date, to_date } = req.query;
    const products = Analytics.getMostViewedProducts(parseInt(limit), { from_date, to_date });
    res.json({ products });
  } catch (error) {
    console.error('Erreur produits vus:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// GET /api/analytics/products/most-ordered - Produits les plus commandés
router.get('/products/most-ordered', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { limit = 10, from_date, to_date } = req.query;
    const products = Analytics.getMostOrderedProducts(parseInt(limit), { from_date, to_date });
    res.json({ products });
  } catch (error) {
    console.error('Erreur produits commandés:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// GET /api/analytics/products/top-conversion - Meilleurs taux de conversion
router.get('/products/top-conversion', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { limit = 10, from_date, to_date } = req.query;
    const products = Analytics.getTopConversionProducts(parseInt(limit), { from_date, to_date });
    res.json({ products });
  } catch (error) {
    console.error('Erreur conversion:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// GET /api/analytics/revenue/by-period - Évolution du CA par période
router.get('/revenue/by-period', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { period = 'day', from_date, to_date, limit } = req.query;
    const data = Order.getRevenueByPeriod(period, { from_date, to_date, limit: limit ? parseInt(limit) : undefined });
    res.json({ data });
  } catch (error) {
    console.error('Erreur revenue period:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// GET /api/analytics/revenue/by-category - CA par catégorie
router.get('/revenue/by-category', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { from_date, to_date } = req.query;
    const data = Analytics.getRevenueByCategory({ from_date, to_date });
    res.json({ data });
  } catch (error) {
    console.error('Erreur revenue category:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// GET /api/analytics/traffic/by-period - Évolution du trafic
router.get('/traffic/by-period', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { period = 'day', from_date, to_date, limit } = req.query;
    const data = Analytics.getTrafficByPeriod(period, { from_date, to_date, limit: limit ? parseInt(limit) : undefined });
    res.json({ data });
  } catch (error) {
    console.error('Erreur traffic:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// GET /api/analytics/searches/top - Top recherches
router.get('/searches/top', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { limit = 10, from_date, to_date } = req.query;
    const searches = Analytics.getTopSearches(parseInt(limit), { from_date, to_date });
    res.json({ searches });
  } catch (error) {
    console.error('Erreur top searches:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// GET /api/analytics/product/:productId - Analytics d'un produit spécifique
router.get('/product/:productId', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { from_date, to_date } = req.query;
    const analytics = Analytics.getProductAnalytics(req.params.productId, { from_date, to_date });
    res.json({ analytics });
  } catch (error) {
    console.error('Erreur analytics produit:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// GET /api/analytics/orders/top-products - Top produits vendus
router.get('/orders/top-products', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { limit = 10, from_date, to_date } = req.query;
    const products = Order.getTopProducts(parseInt(limit), { from_date, to_date });
    res.json({ products });
  } catch (error) {
    console.error('Erreur top products:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// GET /api/analytics/advanced - Analytics avancées (super admin only)
router.get('/advanced', authenticateToken, requireSuperAdmin, async (req, res) => {
  try {
    const { from_date, to_date } = req.query;
    const filters = { from_date, to_date };

    const advanced = {
      globalStats: Analytics.getGlobalStats(filters),
      orderStats: Order.getStats(filters),
      userStats: User.getStats(),
      reviewStats: Review.getGlobalStats(),
      
      topViewed: Analytics.getMostViewedProducts(10, filters),
      topOrdered: Analytics.getMostOrderedProducts(10, filters),
      topConversion: Analytics.getTopConversionProducts(10, filters),
      
      revenueByCategory: Analytics.getRevenueByCategory(filters),
      revenueByPeriod: Order.getRevenueByPeriod('day', { ...filters, limit: 30 }),
      trafficByPeriod: Analytics.getTrafficByPeriod('day', { ...filters, limit: 30 }),
      
      topSearches: Analytics.getTopSearches(20, filters),
      topProducts: Order.getTopProducts(20, filters)
    };

    res.json({ advanced });
  } catch (error) {
    console.error('Erreur analytics avancées:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

module.exports = router;
