const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const Order = require('../models/Order');
const { authenticateToken } = require('../middleware/auth');
const { requireAdmin, requireOwnerOrAdmin } = require('../middleware/roles');
const { handleValidationErrors, validatePagination } = require('../middleware/validator');

// GET /api/orders - Liste des commandes
router.get('/', authenticateToken, validatePagination, async (req, res) => {
  try {
    const { status, from_date, to_date, search } = req.query;
    const { page, limit, offset } = req.pagination;

    const filters = {
      user_id: req.user.role === 'client' ? req.user.id : undefined,
      status, from_date, to_date, search, limit, offset
    };

    const orders = Order.getAll(filters);
    const total = Order.count(filters);

    res.json({
      orders,
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) }
    });
  } catch (error) {
    console.error('Erreur récupération commandes:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// GET /api/orders/:id - Détails commande
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const order = Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({ error: 'Commande non trouvée' });
    }

    // Vérifier les permissions
    if (req.user.role === 'client' && order.user_id !== req.user.id) {
      return res.status(403).json({ error: 'Accès refusé' });
    }

    res.json({ order });
  } catch (error) {
    console.error('Erreur récupération commande:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// POST /api/orders - Créer une commande
router.post('/', authenticateToken, [
  body('items').isArray({ min: 1 }).withMessage('Au moins un item requis'),
  body('shipping_address').notEmpty().withMessage('Adresse de livraison requise'),
  body('shipping_city').notEmpty().withMessage('Ville requise')
], handleValidationErrors, async (req, res) => {
  try {
    const { items, ...orderData } = req.body;
    orderData.user_id = req.user.id;

    const order = Order.create(orderData, items);
    res.status(201).json({ message: 'Commande créée avec succès', order });
  } catch (error) {
    console.error('Erreur création commande:', error);
    res.status(500).json({ error: 'Erreur lors de la création' });
  }
});

// PUT /api/orders/:id/status - Mettre à jour le statut (admin only)
router.put('/:id/status', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { status, tracking_number, transaction_id } = req.body;
    const order = Order.updateStatus(req.params.id, status, { tracking_number, transaction_id });
    res.json({ message: 'Statut mis à jour', order });
  } catch (error) {
    console.error('Erreur mise à jour statut:', error);
    res.status(500).json({ error: 'Erreur lors de la mise à jour' });
  }
});

// POST /api/orders/:id/cancel - Annuler une commande
router.post('/:id/cancel', authenticateToken, async (req, res) => {
  try {
    const order = Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({ error: 'Commande non trouvée' });
    }

    if (req.user.role === 'client' && order.user_id !== req.user.id) {
      return res.status(403).json({ error: 'Accès refusé' });
    }

    if (!['pending_payment', 'payment_confirmed'].includes(order.status)) {
      return res.status(400).json({ error: 'Cette commande ne peut plus être annulée' });
    }

    const cancelledOrder = Order.cancel(req.params.id);
    res.json({ message: 'Commande annulée', order: cancelledOrder });
  } catch (error) {
    console.error('Erreur annulation commande:', error);
    res.status(500).json({ error: 'Erreur lors de l\'annulation' });
  }
});

module.exports = router;
