const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const User = require('../models/User');
const { 
  generateAccessToken, 
  generateRefreshToken,
  authenticateToken 
} = require('../middleware/auth');
const { handleValidationErrors } = require('../middleware/validator');

// Validation pour l'inscription
const registerValidation = [
  body('email').isEmail().normalizeEmail().withMessage('Email invalide'),
  body('password')
    .isLength({ min: 6 }).withMessage('Le mot de passe doit contenir au moins 6 caractères')
    .matches(/\d/).withMessage('Le mot de passe doit contenir au moins un chiffre'),
  body('first_name').trim().notEmpty().withMessage('Le prénom est requis'),
  body('last_name').trim().notEmpty().withMessage('Le nom est requis')
];

// Validation pour la connexion
const loginValidation = [
  body('email').isEmail().normalizeEmail().withMessage('Email invalide'),
  body('password').notEmpty().withMessage('Le mot de passe est requis')
];

// POST /api/auth/register - Inscription
router.post('/register', registerValidation, handleValidationErrors, async (req, res) => {
  try {
    const { email, password, first_name, last_name, phone, address, city, postal_code, country } = req.body;

    // Vérifier si l'email existe déjà
    const existingUser = User.findByEmail(email);
    if (existingUser) {
      return res.status(400).json({ error: 'Cet email est déjà utilisé' });
    }

    // Créer l'utilisateur
    const user = User.create({
      email,
      password,
      role: 'client',
      first_name,
      last_name,
      phone,
      address,
      city,
      postal_code,
      country
    });

    // Générer les tokens
    const accessToken = generateAccessToken(user);
    const refreshToken = generateRefreshToken(user);

    res.status(201).json({
      message: 'Inscription réussie',
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        first_name: user.first_name,
        last_name: user.last_name
      },
      accessToken,
      refreshToken
    });
  } catch (error) {
    console.error('Erreur inscription:', error);
    res.status(500).json({ error: 'Erreur lors de l\'inscription' });
  }
});

// POST /api/auth/login - Connexion
router.post('/login', loginValidation, handleValidationErrors, async (req, res) => {
  try {
    const { email, password } = req.body;

    // Trouver l'utilisateur
    const user = User.findByEmail(email);
    if (!user) {
      return res.status(401).json({ error: 'Email ou mot de passe incorrect' });
    }

    // Vérifier si le compte est actif
    if (!user.is_active) {
      return res.status(403).json({ error: 'Ce compte a été désactivé' });
    }

    // Vérifier le mot de passe
    const isPasswordValid = User.verifyPassword(password, user.password_hash);
    if (!isPasswordValid) {
      return res.status(401).json({ error: 'Email ou mot de passe incorrect' });
    }

    // Mettre à jour la dernière connexion
    User.updateLastLogin(user.id);

    // Générer les tokens
    const accessToken = generateAccessToken(user);
    const refreshToken = generateRefreshToken(user);

    res.json({
      message: 'Connexion réussie',
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        first_name: user.first_name,
        last_name: user.last_name
      },
      accessToken,
      refreshToken
    });
  } catch (error) {
    console.error('Erreur connexion:', error);
    res.status(500).json({ error: 'Erreur lors de la connexion' });
  }
});

// GET /api/auth/me - Récupérer l'utilisateur connecté
router.get('/me', authenticateToken, async (req, res) => {
  try {
    const user = User.findById(req.user.id);
    
    if (!user) {
      return res.status(404).json({ error: 'Utilisateur non trouvé' });
    }

    res.json({ user });
  } catch (error) {
    console.error('Erreur récupération utilisateur:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// POST /api/auth/refresh - Rafraîchir le token
router.post('/refresh', async (req, res) => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      return res.status(401).json({ error: 'Refresh token requis' });
    }

    const jwt = require('jsonwebtoken');
    const config = require('../config/config');

    jwt.verify(refreshToken, config.jwt.refreshSecret, (err, decoded) => {
      if (err) {
        return res.status(403).json({ error: 'Refresh token invalide' });
      }

      const user = User.findById(decoded.id);
      if (!user || !user.is_active) {
        return res.status(403).json({ error: 'Utilisateur non trouvé ou désactivé' });
      }

      const newAccessToken = generateAccessToken(user);
      const newRefreshToken = generateRefreshToken(user);

      res.json({
        accessToken: newAccessToken,
        refreshToken: newRefreshToken
      });
    });
  } catch (error) {
    console.error('Erreur refresh token:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// POST /api/auth/change-password - Changer le mot de passe
router.post('/change-password', 
  authenticateToken,
  [
    body('currentPassword').notEmpty().withMessage('Le mot de passe actuel est requis'),
    body('newPassword')
      .isLength({ min: 6 }).withMessage('Le nouveau mot de passe doit contenir au moins 6 caractères')
      .matches(/\d/).withMessage('Le nouveau mot de passe doit contenir au moins un chiffre')
  ],
  handleValidationErrors,
  async (req, res) => {
    try {
      const { currentPassword, newPassword } = req.body;

      const user = User.findByEmail(req.user.email);
      if (!user) {
        return res.status(404).json({ error: 'Utilisateur non trouvé' });
      }

      // Vérifier le mot de passe actuel
      const isPasswordValid = User.verifyPassword(currentPassword, user.password_hash);
      if (!isPasswordValid) {
        return res.status(401).json({ error: 'Mot de passe actuel incorrect' });
      }

      // Changer le mot de passe
      User.changePassword(user.id, newPassword);

      res.json({ message: 'Mot de passe modifié avec succès' });
    } catch (error) {
      console.error('Erreur changement mot de passe:', error);
      res.status(500).json({ error: 'Erreur lors du changement de mot de passe' });
    }
  }
);

// POST /api/auth/logout - Déconnexion (côté client, invalider les tokens)
router.post('/logout', authenticateToken, (req, res) => {
  // Dans une vraie application, on ajouterait le token à une blacklist
  res.json({ message: 'Déconnexion réussie' });
});

module.exports = router;
