const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const Review = require('../models/Review');
const { authenticateToken, optionalAuth } = require('../middleware/auth');
const { requireAdmin } = require('../middleware/roles');
const { handleValidationErrors, validatePagination } = require('../middleware/validator');

// GET /api/reviews - Liste des avis
router.get('/', optionalAuth, validatePagination, async (req, res) => {
  try {
    const { product_id, rating, is_approved, sort } = req.query;
    const { page, limit, offset } = req.pagination;

    const filters = {
      product_id,
      rating: rating ? parseInt(rating) : undefined,
      is_approved: req.user?.role === 'admin' || req.user?.role === 'super_admin' ? undefined : 1,
      sort,
      limit,
      offset
    };

    const reviews = Review.getAll(filters);
    const total = Review.count(filters);

    res.json({
      reviews,
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) }
    });
  } catch (error) {
    console.error('Erreur récupération avis:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// GET /api/reviews/product/:productId/stats - Stats avis d'un produit
router.get('/product/:productId/stats', async (req, res) => {
  try {
    const stats = Review.getProductReviewStats(req.params.productId);
    res.json({ stats });
  } catch (error) {
    console.error('Erreur stats avis:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// GET /api/reviews/:id - Détails d'un avis
router.get('/:id', async (req, res) => {
  try {
    const review = Review.findById(req.params.id);
    if (!review) {
      return res.status(404).json({ error: 'Avis non trouvé' });
    }
    res.json({ review });
  } catch (error) {
    console.error('Erreur récupération avis:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// POST /api/reviews - Créer un avis
router.post('/', authenticateToken, [
  body('product_id').isInt().withMessage('ID produit requis'),
  body('rating').isInt({ min: 1, max: 5 }).withMessage('Note entre 1 et 5'),
  body('comment').optional().trim()
], handleValidationErrors, async (req, res) => {
  try {
    const { product_id, order_id, rating, title, comment } = req.body;

    // Vérifier si l'utilisateur peut laisser un avis
    const canReview = Review.canUserReview(req.user.id, product_id);
    
    if (!canReview.canReview) {
      if (!canReview.hasPurchased) {
        return res.status(403).json({ error: 'Vous devez acheter ce produit pour laisser un avis' });
      }
      if (canReview.hasReviewed) {
        return res.status(400).json({ error: 'Vous avez déjà laissé un avis pour ce produit' });
      }
    }

    const review = Review.create({
      product_id,
      user_id: req.user.id,
      order_id,
      rating,
      title,
      comment
    });

    res.status(201).json({
      message: 'Avis créé avec succès. Il sera publié après modération.',
      review
    });
  } catch (error) {
    console.error('Erreur création avis:', error);
    res.status(500).json({ error: 'Erreur lors de la création' });
  }
});

// PUT /api/reviews/:id - Mettre à jour un avis
router.put('/:id', authenticateToken, async (req, res) => {
  try {
    const review = Review.findById(req.params.id);
    
    if (!review) {
      return res.status(404).json({ error: 'Avis non trouvé' });
    }

    // Seul l'auteur ou un admin peut modifier
    if (review.user_id !== req.user.id && !['admin', 'super_admin'].includes(req.user.role)) {
      return res.status(403).json({ error: 'Accès refusé' });
    }

    const updatedReview = Review.update(req.params.id, req.body);
    res.json({ message: 'Avis mis à jour', review: updatedReview });
  } catch (error) {
    console.error('Erreur mise à jour avis:', error);
    res.status(500).json({ error: 'Erreur lors de la mise à jour' });
  }
});

// POST /api/reviews/:id/approve - Approuver un avis (admin only)
router.post('/:id/approve', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const review = Review.approve(req.params.id);
    res.json({ message: 'Avis approuvé', review });
  } catch (error) {
    console.error('Erreur approbation avis:', error);
    res.status(500).json({ error: 'Erreur lors de l\'approbation' });
  }
});

// POST /api/reviews/:id/reject - Rejeter un avis (admin only)
router.post('/:id/reject', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const review = Review.reject(req.params.id);
    res.json({ message: 'Avis rejeté', review });
  } catch (error) {
    console.error('Erreur rejet avis:', error);
    res.status(500).json({ error: 'Erreur lors du rejet' });
  }
});

// POST /api/reviews/:id/helpful - Marquer un avis comme utile
router.post('/:id/helpful', async (req, res) => {
  try {
    const review = Review.markHelpful(req.params.id);
    res.json({ message: 'Merci pour votre retour', review });
  } catch (error) {
    console.error('Erreur helpful:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// GET /api/reviews/admin/pending - Avis en attente (admin only)
router.get('/admin/pending', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const reviews = Review.getPendingReviews();
    res.json({ reviews });
  } catch (error) {
    console.error('Erreur avis en attente:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// DELETE /api/reviews/:id - Supprimer un avis
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    const review = Review.findById(req.params.id);
    
    if (!review) {
      return res.status(404).json({ error: 'Avis non trouvé' });
    }

    if (review.user_id !== req.user.id && !['admin', 'super_admin'].includes(req.user.role)) {
      return res.status(403).json({ error: 'Accès refusé' });
    }

    Review.delete(req.params.id);
    res.json({ message: 'Avis supprimé' });
  } catch (error) {
    console.error('Erreur suppression avis:', error);
    res.status(500).json({ error: 'Erreur lors de la suppression' });
  }
});

module.exports = router;
