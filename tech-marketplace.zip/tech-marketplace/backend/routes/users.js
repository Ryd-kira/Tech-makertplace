const express = require('express');
const router = express.Router();
const User = require('../models/User');
const { authenticateToken } = require('../middleware/auth');
const { requireAdmin, requireOwnerOrAdmin } = require('../middleware/roles');
const { validatePagination } = require('../middleware/validator');

// GET /api/users - Liste utilisateurs (admin only)
router.get('/', authenticateToken, requireAdmin, validatePagination, async (req, res) => {
  try {
    const { role, is_active, search } = req.query;
    const { page, limit, offset } = req.pagination;

    const filters = { role, is_active, search, limit, offset };
    const users = User.getAll(filters);
    const total = User.count(filters);

    res.json({
      users,
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) }
    });
  } catch (error) {
    console.error('Erreur récupération utilisateurs:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// GET /api/users/:id - Détails utilisateur
router.get('/:id', authenticateToken, requireOwnerOrAdmin(req => parseInt(req.params.id)), async (req, res) => {
  try {
    const user = User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ error: 'Utilisateur non trouvé' });
    }
    res.json({ user });
  } catch (error) {
    console.error('Erreur récupération utilisateur:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// PUT /api/users/:id - Mettre à jour un utilisateur
router.put('/:id', authenticateToken, requireOwnerOrAdmin(req => parseInt(req.params.id)), async (req, res) => {
  try {
    const user = User.update(req.params.id, req.body);
    res.json({ message: 'Utilisateur mis à jour', user });
  } catch (error) {
    console.error('Erreur mise à jour utilisateur:', error);
    res.status(500).json({ error: 'Erreur lors de la mise à jour' });
  }
});

// DELETE /api/users/:id - Désactiver un utilisateur (admin only)
router.delete('/:id', authenticateToken, requireAdmin, async (req, res) => {
  try {
    User.delete(req.params.id);
    res.json({ message: 'Utilisateur désactivé' });
  } catch (error) {
    console.error('Erreur suppression utilisateur:', error);
    res.status(500).json({ error: 'Erreur lors de la suppression' });
  }
});

module.exports = router;
