const express = require('express');
const router = express.Router();
const { db } = require('../database');
const { optionalAuth } = require('../middleware/auth');
const Analytics = require('../models/Analytics');

// Récupérer le panier
router.get('/', optionalAuth, async (req, res) => {
  try {
    const sessionId = req.headers['x-session-id'] || 'anonymous';
    const userId = req.user?.id;

    let query = `
      SELECT ci.*, 
             p.name as product_name, 
             p.base_price, 
             p.featured_image,
             p.stock_total,
             pv.name as variant_name,
             pv.price_adjustment,
             pv.stock as variant_stock
      FROM cart_items ci
      LEFT JOIN products p ON ci.product_id = p.id
      LEFT JOIN product_variants pv ON ci.variant_id = pv.id
      WHERE ${userId ? 'ci.user_id = ?' : 'ci.session_id = ?'}
    `;

    const stmt = db.prepare(query);
    const items = stmt.all(userId || sessionId);

    // Calculer le total
    const total = items.reduce((sum, item) => {
      const price = item.base_price + (item.price_adjustment || 0);
      return sum + (price * item.quantity);
    }, 0);

    res.json({ items, total, itemCount: items.length });
  } catch (error) {
    console.error('Erreur récupération panier:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// Ajouter au panier
router.post('/add', optionalAuth, async (req, res) => {
  try {
    const { product_id, variant_id, quantity = 1 } = req.body;
    const sessionId = req.headers['x-session-id'] || 'anonymous';
    const userId = req.user?.id;

    // Vérifier le stock
    let stockQuery = variant_id 
      ? 'SELECT stock FROM product_variants WHERE id = ?'
      : 'SELECT stock_total as stock FROM products WHERE id = ?';
    
    const stockStmt = db.prepare(stockQuery);
    const stockData = stockStmt.get(variant_id || product_id);

    if (!stockData || stockData.stock < quantity) {
      return res.status(400).json({ error: 'Stock insuffisant' });
    }

    // Vérifier si l'item existe déjà dans le panier
    const existingStmt = db.prepare(`
      SELECT id, quantity FROM cart_items
      WHERE product_id = ? 
        AND ${variant_id ? 'variant_id = ?' : 'variant_id IS NULL'}
        AND ${userId ? 'user_id = ?' : 'session_id = ?'}
    `);

    const params = variant_id 
      ? [product_id, variant_id, userId || sessionId]
      : [product_id, userId || sessionId];

    const existing = existingStmt.get(...params);

    if (existing) {
      // Mettre à jour la quantité
      const newQuantity = existing.quantity + quantity;
      
      if (stockData.stock < newQuantity) {
        return res.status(400).json({ error: 'Stock insuffisant' });
      }

      const updateStmt = db.prepare(`
        UPDATE cart_items 
        SET quantity = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `);
      updateStmt.run(newQuantity, existing.id);
    } else {
      // Ajouter nouveau item
      const insertStmt = db.prepare(`
        INSERT INTO cart_items (user_id, session_id, product_id, variant_id, quantity)
        VALUES (?, ?, ?, ?, ?)
      `);
      insertStmt.run(userId || null, userId ? null : sessionId, product_id, variant_id || null, quantity);
    }

    // Tracker l'événement
    Analytics.trackEvent({
      event_type: 'add_to_cart',
      product_id,
      variant_id: variant_id || null,
      user_id: userId,
      session_id: sessionId,
      ip_address: req.ip,
      user_agent: req.headers['user-agent']
    });

    res.json({ message: 'Produit ajouté au panier' });
  } catch (error) {
    console.error('Erreur ajout panier:', error);
    res.status(500).json({ error: 'Erreur lors de l\'ajout' });
  }
});

// Mettre à jour la quantité
router.put('/:itemId', optionalAuth, async (req, res) => {
  try {
    const { quantity } = req.body;
    const sessionId = req.headers['x-session-id'] || 'anonymous';
    const userId = req.user?.id;

    if (quantity < 1) {
      return res.status(400).json({ error: 'La quantité doit être >= 1' });
    }

    // Vérifier que l'item appartient à l'utilisateur/session
    const itemStmt = db.prepare(`
      SELECT ci.*, 
             COALESCE(pv.stock, p.stock_total) as available_stock
      FROM cart_items ci
      LEFT JOIN products p ON ci.product_id = p.id
      LEFT JOIN product_variants pv ON ci.variant_id = pv.id
      WHERE ci.id = ? 
        AND ${userId ? 'ci.user_id = ?' : 'ci.session_id = ?'}
    `);

    const item = itemStmt.get(req.params.itemId, userId || sessionId);

    if (!item) {
      return res.status(404).json({ error: 'Item non trouvé' });
    }

    if (item.available_stock < quantity) {
      return res.status(400).json({ error: 'Stock insuffisant' });
    }

    const updateStmt = db.prepare(`
      UPDATE cart_items 
      SET quantity = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `);
    updateStmt.run(quantity, req.params.itemId);

    res.json({ message: 'Quantité mise à jour' });
  } catch (error) {
    console.error('Erreur mise à jour panier:', error);
    res.status(500).json({ error: 'Erreur lors de la mise à jour' });
  }
});

// Supprimer un item
router.delete('/:itemId', optionalAuth, async (req, res) => {
  try {
    const sessionId = req.headers['x-session-id'] || 'anonymous';
    const userId = req.user?.id;

    // Récupérer l'item pour tracker l'événement
    const itemStmt = db.prepare(`
      SELECT product_id, variant_id FROM cart_items
      WHERE id = ? AND ${userId ? 'user_id = ?' : 'session_id = ?'}
    `);
    const item = itemStmt.get(req.params.itemId, userId || sessionId);

    if (!item) {
      return res.status(404).json({ error: 'Item non trouvé' });
    }

    // Supprimer
    const deleteStmt = db.prepare('DELETE FROM cart_items WHERE id = ?');
    deleteStmt.run(req.params.itemId);

    // Tracker l'événement
    Analytics.trackEvent({
      event_type: 'remove_from_cart',
      product_id: item.product_id,
      variant_id: item.variant_id,
      user_id: userId,
      session_id: sessionId,
      ip_address: req.ip,
      user_agent: req.headers['user-agent']
    });

    res.json({ message: 'Produit retiré du panier' });
  } catch (error) {
    console.error('Erreur suppression panier:', error);
    res.status(500).json({ error: 'Erreur lors de la suppression' });
  }
});

// Vider le panier
router.delete('/', optionalAuth, async (req, res) => {
  try {
    const sessionId = req.headers['x-session-id'] || 'anonymous';
    const userId = req.user?.id;

    const deleteStmt = db.prepare(`
      DELETE FROM cart_items 
      WHERE ${userId ? 'user_id = ?' : 'session_id = ?'}
    `);
    deleteStmt.run(userId || sessionId);

    res.json({ message: 'Panier vidé' });
  } catch (error) {
    console.error('Erreur vidage panier:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// Migrer le panier d'une session vers un utilisateur (après connexion)
router.post('/migrate', optionalAuth, async (req, res) => {
  try {
    const { sessionId } = req.body;
    const userId = req.user?.id;

    if (!userId) {
      return res.status(401).json({ error: 'Authentification requise' });
    }

    const migrateStmt = db.prepare(`
      UPDATE cart_items 
      SET user_id = ?, session_id = NULL
      WHERE session_id = ?
    `);
    migrateStmt.run(userId, sessionId);

    res.json({ message: 'Panier migré' });
  } catch (error) {
    console.error('Erreur migration panier:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

module.exports = router;
