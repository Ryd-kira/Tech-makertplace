// Middleware pour vérifier les rôles utilisateur
const requireRole = (...allowedRoles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Authentification requise' });
    }

    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ 
        error: 'Accès refusé',
        message: 'Vous n\'avez pas les permissions nécessaires pour cette action'
      });
    }

    next();
  };
};

// Vérifier si admin ou super_admin
const requireAdmin = requireRole('admin', 'super_admin');

// Vérifier si super_admin uniquement
const requireSuperAdmin = requireRole('super_admin');

// Vérifier si propriétaire de la ressource ou admin
const requireOwnerOrAdmin = (getUserIdFromRequest) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Authentification requise' });
    }

    const userId = getUserIdFromRequest(req);
    
    // Admin et super_admin ont accès à tout
    if (req.user.role === 'admin' || req.user.role === 'super_admin') {
      return next();
    }

    // Sinon, vérifier si c'est le propriétaire
    if (req.user.id === userId) {
      return next();
    }

    return res.status(403).json({ 
      error: 'Accès refusé',
      message: 'Vous ne pouvez accéder qu\'à vos propres ressources'
    });
  };
};

module.exports = {
  requireRole,
  requireAdmin,
  requireSuperAdmin,
  requireOwnerOrAdmin
};
